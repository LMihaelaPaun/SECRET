This code is provided as-is, but not supported. A snapshot of experimental code hastily-written for a competition entry.

Everything was run on a GNU/Linux system (Ubuntu 22.04).


Run simulations and process the resulting data for learning a surrogate model:

    # Set up 100k simulations, and run saving all output in ./out directory (takes ~5 days on 64 core machine)
    python3 setup_params.py > PARAMS
    mkdir out
    parallel < PARAMS

    # Use provided code to process and store all results in separate Matlab format files in ./out2 directory
    mkdir out2
    ./proc_out_jobs.py | parallel

    # Create single large (1.1G) numpy file, simulations.npz
    python3 write_one_out.py

    Uses:
        wrap - shell script to drive the sor06 simulator
        proc_out2_for_parallel.m - octave script (so need octave installed, a free Matlab-compatible interpretor). Uses "gnuplot.m" from competition release.
        GNU parallel to run jobs (to run simulations in sequence just do "sh PARAMS")


Fit neural net:
    python3 equinox_play.py
    Requires equinox which is pip-installable, and velo (although that dependency can be removed), which is a nightmare to install.
    With velo it's a bit painful without a GPU. Without velo, running on CPU is fine.

    OR version to fit larger model that also adds in a GP loss to probe how hard it is to get a model that can totally replace real simulator in MCMC with no difference in results. (Answer: hard!)
    python3 equinox_gp_loss_again_larger_net.py


Run MCMC:
    python3 emcee_gp_noise_challenge_data.py
    python3 save_out_results.py
    Needs:
        observed data in PulmFilePressure.txt and PulmFileFlow.txt
        trained model from previous step in mynet_velo.eqx
        emcee which is pip-installable

    OR version on larger model, slightly updated after competition:
    python3 emcee_gp_noise_challenge_data_comp_run_large_model_gp_noise.py

