#!/usr/bin/env python3

# After competition, redid with larger model that had also been trained to care about a GP loss.
# Had to tweak some code to prevent running out of memory.
# Also restricted hyper-parameter range and saved out results to report directly from here.

import numpy as np
import scipy.io as spio
import matplotlib.pyplot as plt
import scipy.special as spsp
import scipy.stats as spst
import scipy.linalg as spla
st = spla.solve_triangular

# working assumption for now (just for fit of initialization):
obs_variance = 19.59

# XXX hard-coded bounds for this problem.
Xmn = np.array([9e4, 0.83, 20, 20])
Xmx = np.array([3e5, 0.89, 50, 50])
width = Xmx - Xmn
middle_of_box = Xmn + 0.5*width
def scale(X):
    return 2 * (X - Xmn) / width - 1.0

# How was data concatenated together for model?
"""
job_str = '99999'
data = spio.loadmat(f'out2/output_{job_str}.2d.mat')
keys = [x for x in data.keys() if not x.startswith('_')]
for k in keys:
    print('key:', k)
key: pressure1
key: flow17
key: flow19
"""

# Get data and munge into same format as model (ravelled, but no centering or scaling XXX might want change that!)
pressure1 = np.loadtxt('PulmFilePressure.txt')
flows_17_19 = np.loadtxt('PulmFileFlow.txt')
obs_output = np.hstack([pressure1, flows_17_19.T.ravel()])

def k_of_r(r, sigma2_m):
    """Matern 3/2 kernel as a function of separation r"""
    sqrt3_r = np.sqrt(3) * r
    return sigma2_m*(1 + sqrt3_r)*np.exp(-sqrt3_r)
sigma2_noise = 1e-6 # fixed known noise variance we've been given
times = np.linspace(0, 1, 512)
num_series = 3

import equinox as eqx
import jax
import jax.numpy as jnp
class PreluResNet(eqx.Module):
    in_layer: eqx.nn.Linear
    out_layer: eqx.nn.Linear
    layers: list
    prelus: list

    def __init__(self, din, dout, dhid, nres_layers, key):
        """layer_sizes includes input and output"""
        kin, kout, key = jax.random.split(key, 3)
        res_keys = jax.random.split(key, nres_layers)
        self.in_layer = eqx.nn.Linear(din, dhid, key=kin)
        self.out_layer = eqx.nn.Linear(dhid, dout, key=kout)
        self.layers = [eqx.nn.Linear(dhid, dhid, key=k) for k in res_keys]
        self.prelus = [eqx.nn.PReLU(jnp.tile(0.25, dhid)) for i in range(nres_layers + 1)]

    def __call__(self, x):
        x = self.prelus[0](self.in_layer(x))
        for layer, prelu in zip(self.layers, self.prelus[1:]):
            x = x + prelu(layer(x))
        return self.out_layer(x)
key = jax.random.PRNGKey(0)
class model:
    pass
# original run:
#model.predict = PreluResNet(width.size, obs_output.size, 100, 15, key)
#model.predict = eqx.tree_deserialise_leaves("mynet_velo.eqx", model.predict)
# New bigger model, trained to care about GP loss:
OUT_SIZE = 512*3
model.predict = PreluResNet(width.size, OUT_SIZE, 1000, 15, key)
model.predict = eqx.tree_deserialise_leaves("mynet_gp_and_se_large_net.eqx", model.predict)

model.predict = jax.jit(jax.vmap(model.predict))

def look_param_fit(params):
    plt.clf()
    plt.plot(obs_output, 'b')
    #plt.plot(clean_obs_output, 'g')
    plt.plot(model.predict(scale(params[None,:])).ravel(), 'r--')

def batch_log_pdf(X, model=model):
    # Takes (N,D) batch of D-dimensional parameters
    Xs = scale(X) # XXX model was trained using scaled inputs (but original outputs).
    mask = np.all((X > Xmn) & (X < Xmx), axis=1)
    log_probs = np.tile(-1e300, X.shape[0])
    if np.any(mask):
        residuals = model.predict(Xs[mask]) - obs_output
        log_probs[mask] = -0.5*np.sum(residuals**2, 1) / obs_variance
    return log_probs

def log_pdf(X):
    # log_pdf of one parameter vector shape (D,).
    # Use if want to try more straightforward/standard emcee usage, without the `pool=NpBatchOpPool()` (which is slower).
    return batch_log_pdf(X[None,:])

def neg_log_pdf(X):
    # For minimizing
    return -batch_log_pdf(X[None,:])

# Initial fit sim params
import scipy.optimize
opt_out = scipy.optimize.minimize(neg_log_pdf, middle_of_box, bounds=list(zip(Xmn, Xmx)), method='powell')
fit_params = opt_out.x

"""
plt.figure(1); look_param_fit(fit_params)
"""

# Initial fit GP hypers with sim params fixed
fit1_residuals = (model.predict(scale(fit_params[None,:])) - obs_output).reshape([num_series,-1])

def neg_log_marg_like(hypers, yys):
    ell, sigma2_m = np.exp(hypers)
    cc = k_of_r(times/ell, sigma2_m)
    cc[0] += sigma2_noise
    cho = spla.cho_factor(spla.toeplitz(cc))
    alpha = spla.cho_solve(cho, yys.T) # T,num_series
    num_series = yys.shape[0]
    return 0.5 * np.sum(yys * alpha.T) + num_series*np.sum(np.log(np.diag(cho[0]))) + 0.5*yys.size*np.log(2*np.pi)

opt_out2 = scipy.optimize.minimize(neg_log_marg_like, [0.0, 0.0], args=(fit1_residuals,), method='powell')
fit_hypers = opt_out2.x
fit_ell, fit_sigma2_m = np.exp(fit_hypers)


# Joint fit from there
def joint_neg_log_pdf(XX):
    hypers = XX[:2]
    X = XX[2:]
    if np.any(X < Xmn) or np.any(X > Xmx) or (hypers[1] > np.log(22.5)):
        return 1e300
    residuals = (model.predict(scale(X[None,:])) - obs_output).reshape([num_series,-1])
    return neg_log_marg_like(hypers, residuals)

init_joint = np.array(list(fit_hypers) + list(fit_params))
opt_out3 = scipy.optimize.minimize(joint_neg_log_pdf, init_joint, method='powell')
fit_joint = opt_out3.x
fit3_ell = np.exp(fit_joint[0])
fit3_sigma2_m = np.exp(fit_joint[1])
fit3_params = fit_joint[2:]

"""
plt.figure(2); look_param_fit(fit3_params)
# barely moves, not sure looks convincingly better? Might even be worse? On another run did look better. Too much due to chance evaluating on one run!

plt.figure(3); plt.clf(); plt.plot(fit1_residuals.T)
"""

# MCMC
import emcee
#class NpBatchOpPool():
#    """Pass a member of this class as pool option to emcee-EnsembleSampler.
#    The logprob function can then evaluate a (nwalkers/2,ndim) shape batch of examples at a time.
#    Makes the computation much faster if fusing the computation of multiple likelihoods is faster."""
#    def map(self, fn, x):
#        return iter(fn(np.asarray(x)))
# To keep memory under control, limit size of batch:
class NpBatchOpPool():
    """Pass a member of this class as pool option to emcee-EnsembleSampler.
    The logprob function can then evaluate a (nwalkers/2,ndim) shape batch of examples at a time.
    Makes the computation much faster if fusing the computation of multiple likelihoods is faster."""
    def map(self, fn, x):
        x = np.asarray(x)
        MAX_BATCH_SIZE = 128
        start = 0
        vals = []
        while start < len(x):
            vals.extend(list(fn(x[start:start+MAX_BATCH_SIZE])))
            start += MAX_BATCH_SIZE
        return iter(vals)

nwalkers = 500
nsteps = 5000
burn_in = 500
# XXX
nwalkers = 128
nsteps = 500
burn_in = 100
# XXX
nwalkers = 500 # Ugh with large neural net uses most of memory on 16GB machine, painful.
nsteps = 1000
burn_in = 500
# 128 walkers * 500 nsteps took ~8.5 minutes on my laptop (19 mins CPU time). (With large model took 3min 32s on desktop)
# 500 walkers 1000 steps took 23min on desktop, after tweaking pool to limit batch size to 128. -- "should" have run for ~2500 steps, not 1000.
# ~30 autocor time. *strong* correlation between GP hypers, but emcee fine with that. corner plot looks "ok".
# Individual trace plots look "ok", but slightly scary. But if plot several walkers for same param, they cross over each other healthily and looks ok.
# plt.clf(); plt.plot(params[:,:5,4])
# to see 5 walkers for the (4+1)th parameter
###
#p0 = true_params + 0.01 * width * np.random.randn(nwalkers, ndim) # At first cheated to get started, and to check didn't wander completely off truth
#p0 = fit_params + 0.01 * width * np.random.randn(nwalkers, ndim) # But now use Powell optimization, which works well! (Could use gradient based if do own neural net, but not necessary.)
#p0 = np.minimum(np.maximum(p0, Xmn), Xmx) # keep inside box!

ndim = fit_joint.size
p0 = fit_joint[None,:] + 0.01 * np.hstack([fit_joint[:2], width])* np.random.randn(nwalkers, ndim)
p0[:,2:] = np.minimum(np.maximum(p0[:,2:], Xmn), Xmx) # keep inside box!
p0[:,1] = np.minimum(p0[:,1], np.log(22.5)) # keep inside box!

def batch_joint_log_pdf(XX):
    # Takes (N,D) batch of D-dimensional parameters
    hypers = XX[:,:2]
    X = XX[:,2:]
    Xs = scale(X) # XXX model was trained using scaled inputs (but original outputs).
    mask = np.all((X >= Xmn) & (X <= Xmx), axis=1) & (hypers[:,1] <= np.log(22.5)) # XXX now restrict sigma2_m as in competition instructions hints
    log_probs = np.tile(-1e300, X.shape[0]) # -inf upsets emcee despite FAQ saying to use it
    if np.any(mask):
        residuals = (model.predict(Xs[mask]) - obs_output).reshape([-1, 3, obs_output.size//3])
        log_probs[mask] = [-neg_log_marg_like(h, r) for h, r in zip(hypers[mask], residuals)] # Haven't made nice batch version of GP bit. jax+vmap was slower (on cpu)!
    return log_probs

sampler = emcee.EnsembleSampler(nwalkers, ndim, batch_joint_log_pdf, pool=NpBatchOpPool())

state = sampler.run_mcmc(p0, nsteps)
params = sampler.get_chain() # (nsteps, nwalkers, ndim)

np.savez_compressed('emcee_params_comp_run_large_net_gp_loss.npz', params=params)
np.savetxt("murray_large_model_pulmonary_samples_with_hypers.txt", params[-1][:, :])

## XXX TODO consider reinitializing walkers around best point(s) after a burn-in, if worried about bad/atypical/spurious local optima?

samples = params[burn_in:].reshape(-1,ndim)
#print('quantiles:', np.mean(samples < true_joint, 0))

print('autocors', sampler.get_autocorr_time())
# ~50. So get ~100 samples from each chain, or 20000 effective samples overall. Plenty! Could be brave and run for shorter? get_autocorr_time will yell at me.

"""
import corner
corner.corner(samples)

look_param_fit(samples[10000])
some_samples = params[999::1000].reshape(-1, ndim)
"""

