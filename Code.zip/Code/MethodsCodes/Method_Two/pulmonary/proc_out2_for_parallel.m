% run with :
% for a in out/output*.gz ; do echo /usr/bin/octave proc_out2_for_parallel.m $a ; done | parallel -j 10
% hmmm, except octave startup time too long, so need to pass each octave instance multiple files.
% use proc_out_jobs.py

num_ves = 27;   % Number of large vessels in the tree
art     = 1:15; % Arteries
ven     = 16:27;% Veins

display([argv{1}, '...']);
for i = 1:length(argv)
    path = argv{i};
    basename = path(find(path == '/')+1:end);
    outfile = ['out2/', strrep(basename, '.gz', '.mat')];
    if exist(outfile)
        continue;
    end
    data = load(path);

    % p - pressure
    % q - flow
    [~,~,p,q,~,~] = gnuplot(data); % extract data

    pressure1 = p(:,art(1)+num_ves); % middle point (x=L/2) pressure prediction in vessel 1 (arteries)
    
    flow17 = -q(:,ven(2)+num_ves); % middle point (x=L/2) flow prediction in vessel 17 (veins)
    flow19 = -q(:,ven(4)+num_ves); % middle point (x=L/2) flow prediction in vessel 19 (veins)

    save('-v7', outfile, 'pressure1', 'flow17', 'flow19');
end

