# Rather than doing fresh run emcee_gp_noise_challenge_data_comp_run.py
# simply do rejection sampling on results of emcee_gp_noise_challenge_data.py

import numpy as np

params = np.load('emcee_params.npz')['params']

# In [4]: params[1000::200].reshape([-1,params.shape[-1]]).shape
# Out[4]: (2560, 6)

#samples = params[1000::200].reshape([-1,params.shape[-1]]) # don't thin when estimating mean!
samples = params[1000::].reshape([-1,params.shape[-1]])

# Chucking out <4% of samples:
# np.mean(samples[:,1] < np.log(22.5))
# 0.96640625

mask = (samples[:,1] < np.log(22.5))

# And makes very little difference to mean. Less than difference that thinning makes!
# print(samples.mean(0))
# print(samples[mask].mean(0))

# Chuck out hypers:
mu = samples[mask,2:].mean(0)

print('Guess of params:')
print(' '.join(['%0.12g']*len(mu)) % tuple(mu))
#np.savetxt("murray_pulmonary_point_est.txt", mu)

# Get 500 thinned samples:
samples = params[999::1000].reshape([-1,params.shape[-1]])
mask = (samples[:,1] < np.log(22.5))
#samples = samples[mask,2:][-500:]
# Now include hypers:
samples = samples[mask,:][-500:]

# And transform them back... -- no, didn't. Whatever do, conventions are annoying. Square quantity? Factors of 2?
# samples[:,:2] = samples[:,:2]

np.savetxt("murray_pulmonary_samples_with_hypers.txt", samples)
