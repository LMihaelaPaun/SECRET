#!/usr/bin/env python3

import numpy as np

N = 100000

#              KMV  alpha lA  lV
mn = np.array([9e4, 0.83, 20, 20])
mx = np.array([3e5, 0.89, 50, 50])

D = mn.size
params = mn + np.random.rand(N, D) * (mx - mn)[None,:]

for i, p in enumerate(params):
    print("./wrap", " ".join("%g" % x for x in p), i)

