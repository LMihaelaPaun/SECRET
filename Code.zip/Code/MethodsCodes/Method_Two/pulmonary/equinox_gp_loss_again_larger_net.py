import equinox as eqx
import jax
import jax.numpy as jnp
import numpy as np
#import scipy.linalg as spla # NOPE using it in jax code, so:
import jax.scipy.linalg as spla

import optax

USE_VELO = True
#USE_VELO = False
if USE_VELO:
    # https://github.com/google/learned_optimization # dependencies pretty hairy and old, not packaged nicely :-(
    from learned_optimization.research.general_lopt import prefab


# XXX hard-coded bounds for this problem.
Xmn = jnp.array([9e4, 0.83, 20, 20])
Xmx = jnp.array([3e5, 0.89, 50, 50])
width = Xmx - Xmn
middle_of_box = Xmn + 0.5*width
def scale(X):
    return 2 * (X - Xmn) / width - 1.0

if True:
    data = jnp.load('simulations.npz')
    inputs = jnp.asarray(data['inputs'])
    outputs = jnp.asarray(data['outputs'])
    ntrain = 80000
    nval = 10000
else:
    inputs = jnp.asarray(np.random.randn(1000, 4))
    outputs = jnp.asarray(np.random.randn(1000, 7))
    ntrain = 200
    nval = 200

inputs_scaled = scale(inputs)
xs_train = inputs_scaled[:ntrain]
xs_val = inputs_scaled[ntrain:(ntrain+nval)]
D = xs_train.shape[1]
y_train = outputs[:ntrain]
y_val = outputs[ntrain:(ntrain+nval)]

class PreluResNet(eqx.Module):
    in_layer: eqx.nn.Linear
    out_layer: eqx.nn.Linear
    layers: list
    prelus: list

    def __init__(self, din, dout, dhid, nres_layers, key):
        """layer_sizes includes input and output"""
        kin, kout, key = jax.random.split(key, 3)
        res_keys = jax.random.split(key, nres_layers)
        self.in_layer = eqx.nn.Linear(din, dhid, key=kin)
        self.out_layer = eqx.nn.Linear(dhid, dout, key=kout)
        self.layers = [eqx.nn.Linear(dhid, dhid, key=k) for k in res_keys]
        self.prelus = [eqx.nn.PReLU(jnp.tile(0.25, dhid)) for i in range(nres_layers + 1)]

    def __call__(self, x):
        x = self.prelus[0](self.in_layer(x))
        for layer, prelu in zip(self.layers, self.prelus[1:]):
            x = x + prelu(layer(x))
        return self.out_layer(x)

def k_of_r(r, sigma2_m):
    """Matern 3/2 kernel as a function of separation r"""
    sqrt3_r = np.sqrt(3) * r
    return sigma2_m*(1 + sqrt3_r)*np.exp(-sqrt3_r)
sigma2_noise = 1e-6 # fixed known noise variance we've been given
times = np.linspace(0, 0.85, 512) # period is 0.85 seconds. Makes ell be in units of seconds. XXX might have wrong.
num_series = 3

# original loss
def square_loss(pred_y, yy):
    return jnp.mean((yy - pred_y)**2)

@eqx.filter_jit
def make_step(model, X, yy, opt_state):
    ll, grads = eqx.filter_value_and_grad(loss)(model, X, yy)
    if USE_VELO:
        params, static = eqx.partition(model, eqx.is_array)
        updates, opt_state = optim.update(grads, opt_state, params=params, extra_args={"loss": ll})
    else:
        updates, opt_state = optim.update(grads, opt_state)
    model = eqx.apply_updates(model, updates)
    return ll, model, opt_state

def minibatchify(xx):
    return xx.reshape((-1,100) + xx.shape[1:])

key = jax.random.PRNGKey(0)
model = PreluResNet(D, y_train.shape[1], 1000, 15, key)
#model = PreluResNet(D, y_train.shape[1], 5, 1, key) # tiny version for testing

num_epochs = 1000
num_minibatches = minibatchify(y_train).shape[0]

ell = 0.1 # XXX see above
sigma2_m = 5.8 # XXX might also be wrong if actually sigma_m...
cc = k_of_r(times/ell, sigma2_m)
cc[0] += sigma2_noise
cho = spla.cho_factor(spla.toeplitz(cc)) # XXX if hypers changing will have to put back in.
#inv_Sigma = spla.inv(spla.toeplitz(cc))
R = spla.inv(cho[0].T)
def gp_neg_log_marg_like(yys):
    # alpha = spla.cho_solve(cho, yys.T) # T,num_series
    # #num_series = yys.shape[0] # XXX by not using global num_series, can smush together series from multiple datapoints all using the same gp hypers.
    # #return 0.5 * jnp.sum(yys * alpha.T) + num_series*jnp.sum(jnp.log(jnp.diag(cho[0]))) + 0.5*yys.size*jnp.log(2*jnp.pi)
    # # if hypers fixed, can drop constants... (if not dropping, could at least pre-compute!)
    # #return 0.5 * jnp.sum(yys * alpha.T)
    # return jnp.mean(yys * alpha.T) # 0.5 doesn't matter if just some loss, and use mean so train and val losses comparable
    #
    #return jnp.mean(yys * (yys @ inv_Sigma)) # blows up.
    #
    vv = (R @ yys.T)
    return (vv.ravel() @ vv.ravel()) / vv.size

# XXX now care about errors that will be able to see through GP noise:
def gp_loss(pred_y, yy):
    #residuals = (yy - pred_y).reshape([-1, num_series, yy.shape[1]//num_series])
    residuals = (yy - pred_y).reshape([-1, times.size]) # smush together the series from multiple datapoints all into one squence
    return gp_neg_log_marg_like(residuals)

# Good values I've seen, so can scale to be in same ball-park
min_se_loss = 0.0006
min_gp_loss = 0.277

def loss(model, X, yy):
    pred_y = jax.vmap(model)(X).reshape(yy.shape)
    return square_loss(pred_y, yy)/min_se_loss + gp_loss(pred_y, yy)/min_gp_loss

def losses(model, X, yy):
    pred_y = jax.vmap(model)(X).reshape(yy.shape)
    se = square_loss(pred_y, yy)
    gp = gp_loss(pred_y, yy)
    return se/min_se_loss + gp/min_gp_loss, se, gp
jit_losses = eqx.filter_jit(losses)

NUM_STEPS = num_minibatches*num_epochs
if USE_VELO:
    optim = prefab.optax_lopt(NUM_STEPS)
elif True:
    def ramp_up_schedule(cur_step):
        # Over one epoch, ramp up to value I think is likely to be too big
        #return (cur_step / num_minibatches) * 0.01
        #return (jnp.minimum(cur_step, 100) / num_minibatches) * 0.01
        # used for mynet8:
        return 0.001 * jnp.minimum(1.0, cur_step / num_minibatches) * jnp.minimum(1.0, (NUM_STEPS - cur_step) / (NUM_STEPS - num_minibatches))
        # mynet9 continue training:
        #return 0.0001 * jnp.minimum(1.0, cur_step / num_minibatches) * jnp.minimum(1.0, (NUM_STEPS - cur_step) / (NUM_STEPS - num_minibatches))
    #schedule = optax.cosine_decay_schedule(init_value=0.001, decay_steps=NUM_STEPS)
    schedule = ramp_up_schedule
    optim = optax.adam(learning_rate=schedule)
else:
    learning_rate = 0.001
    learning_rate = 0.0001
    optim = optax.adam(learning_rate)
params, static = eqx.partition(model, eqx.is_array)
opt_state = optim.init(params)
x_batches = minibatchify(xs_train)
y_batches = minibatchify(y_train)
with open('gp_and_se_loss_train_mb_large_net.log', 'w') as fid:
    for epoch in range(num_epochs):
        for step, (x, y) in enumerate(zip(x_batches, y_batches)):
            mb_loss, model, opt_state = make_step(model, x, y, opt_state)
            mb_loss = mb_loss.item()
            fid.write('%g\n' % mb_loss)
        val_losses = jit_losses(model, xs_val, y_val)
        train_losses = jit_losses(model, xs_train, y_train)
        print(f"epoch={epoch}, train={['%g' %x for x in train_losses]}, val={['%g' %x for x in val_losses]}")
        # Shuffle minibatches here.
        k, key = jax.random.split(key, 2)
        idx = jax.random.permutation(k, x_batches.shape[0])
        x_batches = x_batches[idx]
        y_batches = y_batches[idx]

eqx.tree_serialise_leaves("mynet_gp_and_se_large_net.eqx", model)
