# Fine tune model on sims from emcee posterior params

import equinox as eqx
import jax
import jax.numpy as jnp
import numpy as np

import optax

USE_VELO = True
#USE_VELO = False
if USE_VELO:
    # https://github.com/google/learned_optimization # dependencies pretty hairy and old, not packaged nicely :-(
    from learned_optimization.research.general_lopt import prefab


# XXX hard-coded bounds for this problem.
Xmn = jnp.array([9e4, 0.83, 20, 20])
Xmx = jnp.array([3e5, 0.89, 50, 50])
width = Xmx - Xmn
middle_of_box = Xmn + 0.5*width
def scale(X):
    return 2 * (X - Xmn) / width - 1.0

data_orig = jnp.load('simulations.npz')
inputs_orig = jnp.asarray(data_orig['inputs'])
outputs_orig = jnp.asarray(data_orig['outputs'])

data_new = jnp.load('simulations_emcee.npz')
inputs_new = jnp.asarray(data_new['inputs'])
outputs_new = jnp.asarray(data_new['outputs'])

inputs_orig_scaled = scale(inputs_orig)
inputs_new_scaled = scale(inputs_new)

ntrain_orig = 80000
nval_orig = 10000
ntrain_from_each = 5000
nval_from_each = inputs_new.shape[0] - ntrain_from_each

# Train data is half from original val set and half from new set. So all new, and half focussed on region of interest, and other half to keep extrapolation sensible.
xs_train = np.zeros((ntrain_from_each*2, inputs_orig.shape[1]))
xs_train[::2] = inputs_orig_scaled[ntrain_orig:(ntrain_orig+ntrain_from_each)]
xs_train[1::2] = inputs_new_scaled[:ntrain_from_each]
y_train = np.zeros((ntrain_from_each*2, outputs_orig.shape[1]))
y_train[::2] = outputs_orig[ntrain_orig:(ntrain_orig+ntrain_from_each)]
y_train[1::2] = outputs_new[:ntrain_from_each]
xs_val = np.vstack([
        inputs_orig_scaled[(ntrain_orig+ntrain_from_each):(ntrain_orig+ntrain_from_each+nval_from_each)],
        inputs_new_scaled[ntrain_from_each:(ntrain_from_each+nval_from_each)]])
y_val = np.vstack([
        outputs_orig[(ntrain_orig+ntrain_from_each):(ntrain_orig+ntrain_from_each+nval_from_each)],
        outputs_new[ntrain_from_each:(ntrain_from_each+nval_from_each)]])
D = xs_train.shape[1]

class LinearModel(eqx.Module):
    params: jax.Array
    bias: jax.Array

    def __init__(self, dim):
        self.params = jnp.zeros(dim)
        self.bias = jnp.zeros(1)

    def __call__(self, X):
        return X @ self.params + self.bias

class MyNet(eqx.Module):
    layers: list

    def __init__(self, layer_sizes, key):
        """layer_sizes includes input and output"""
        keys = jax.random.split(key, len(layer_sizes) - 1)
        self.layers = [eqx.nn.Linear(i, j, key=k) for (i, j, k) in zip(layer_sizes[:-1], layer_sizes[1:], keys)]

    def __call__(self, x):
        for layer in self.layers[:-1]:
            x = jax.nn.relu(layer(x))
        return self.layers[-1](x)

class PreluNet(eqx.Module):
    layers: list
    prelus: list

    def __init__(self, layer_sizes, key):
        """layer_sizes includes input and output"""
        keys = jax.random.split(key, len(layer_sizes) - 1)
        self.layers = [eqx.nn.Linear(i, j, key=k) for (i, j, k) in zip(layer_sizes[:-1], layer_sizes[1:], keys)]
        self.prelus = [eqx.nn.PReLU(jnp.tile(0.25, j)) for j in layer_sizes[1:-1]]

    def __call__(self, x):
        for layer, prelu in zip(self.layers[:-1], self.prelus):
            x = prelu(layer(x))
        return self.layers[-1](x)

class PreluResNet(eqx.Module):
    in_layer: eqx.nn.Linear
    out_layer: eqx.nn.Linear
    layers: list
    prelus: list

    def __init__(self, din, dout, dhid, nres_layers, key):
        """layer_sizes includes input and output"""
        kin, kout, key = jax.random.split(key, 3)
        res_keys = jax.random.split(key, nres_layers)
        self.in_layer = eqx.nn.Linear(din, dhid, key=kin)
        self.out_layer = eqx.nn.Linear(dhid, dout, key=kout)
        self.layers = [eqx.nn.Linear(dhid, dhid, key=k) for k in res_keys]
        self.prelus = [eqx.nn.PReLU(jnp.tile(0.25, dhid)) for i in range(nres_layers + 1)]

    def __call__(self, x):
        x = self.prelus[0](self.in_layer(x))
        for layer, prelu in zip(self.layers, self.prelus[1:]):
            x = x + prelu(layer(x))
        return self.out_layer(x)


def loss(model, X, yy):
    pred_y = jax.vmap(model)(X).reshape(yy.shape)
    return jnp.mean((yy - pred_y)**2)

@eqx.filter_jit
def make_step(model, X, yy, opt_state):
    ll, grads = eqx.filter_value_and_grad(loss)(model, X, yy)
    if USE_VELO:
        params, static = eqx.partition(model, eqx.is_array)
        updates, opt_state = optim.update(grads, opt_state, params=params, extra_args={"loss": ll})
    else:
        updates, opt_state = optim.update(grads, opt_state)
    model = eqx.apply_updates(model, updates)
    return ll, model, opt_state

def minibatchify(xx):
    return xx.reshape((-1,100) + xx.shape[1:])

key = jax.random.PRNGKey(0)
#model = LinearModel(D)
#model = MyNet((D, 1), key)
#model = MyNet((D, 10000, 100, 100, 100, y_train.shape[1]), key)
#model = MyNet((D, 1000, 100, 100, 100, y_train.shape[1]), key) # epoch=844, train=0.002380052115768194, val=0.0025414719711989164 then accidentally killed it. Not doing as well as 10000 unit model. Don't know where it would have finished, but probably not as good.
#model = PreluNet((D, 1000, 100, 100, 100, y_train.shape[1]), key) # loss falling fair bit faster than relus near start, later on seems to be the same. (Haven't tried 10k hids version.)
model = PreluResNet(D, y_train.shape[1], 100, 15, key) # No initial big layer, so might expect to do worse. Tracking 1000 hid, if not better, early on?
#model = PreluResNet(D, y_train.shape[1], 5, 1, key) # tiny version for testing

# XXX Init with previous fit
model = eqx.tree_deserialise_leaves("mynet_velo.eqx", model)

num_epochs = 100
num_minibatches = minibatchify(y_train).shape[0]
NUM_STEPS = num_minibatches*num_epochs
if USE_VELO:
    optim = prefab.optax_lopt(NUM_STEPS)
elif True:
    schedule = optax.cosine_decay_schedule(init_value=0.001, decay_steps=NUM_STEPS)
    optim = optax.adam(learning_rate=schedule)
else:
    learning_rate = 0.001
    learning_rate = 0.0001
    optim = optax.adam(learning_rate)
params, static = eqx.partition(model, eqx.is_array)
opt_state = optim.init(params)
x_batches = minibatchify(xs_train)
y_batches = minibatchify(y_train)
for epoch in range(num_epochs):
    for step, (x, y) in enumerate(zip(x_batches, y_batches)):
        mb_loss, model, opt_state = make_step(model, x, y, opt_state)
        mb_loss = mb_loss.item()
    val_loss = loss(model, xs_val, y_val)
    train_loss = loss(model, xs_train, y_train)
    print(f"epoch={epoch}, train={train_loss}, val={val_loss}")
    # Shuffle minibatches here.
    k, key = jax.random.split(key, 2)
    idx = jax.random.permutation(k, x_batches.shape[0])
    x_batches = x_batches[idx]
    y_batches = y_batches[idx]

import pickle
with open('mynet_velo_emcee_epochs100.pkl', 'wb') as fid:
    pickle.dump(model, fid)
#with open('mynet5.pkl', 'rb') as fid:
#    model = pickle.load(fid)
eqx.tree_serialise_leaves("mynet_velo_emcee_epochs100.eqx", model)
# key = jax.random.PRNGKey(0)
# model = PreluResNet(D, y_train.shape[1], 100, 15, key)
# model = eqx.tree_deserialise_leaves("mynet7.eqx", model)
