#!/usr/bin/env python3

import os, glob, sys
import numpy as np
import get_challenge_output

#NUM_CORES = 32
NUM_CORES = 55

# Find parallel job that's not been done
for runme in glob.glob('PARAMS_stage*'):
    if not runme.endswith('.done') and not os.path.exists(runme + '.done'):
        break
else:
    runme = None

if runme:
    print(runme)
    os.system(f'parallel -j {NUM_CORES} < {runme}')
    os.system(f'./proc_out_jobs.py | parallel -j {NUM_CORES}')
    os.system(f'./write_one_out_probes.py')
    os.system(f'touch {runme}.done')

data = np.load('simulations_probes.npz')
probe_inputs = data['inputs']
probe_outputs = data['outputs']

obs_output_full = get_challenge_output.get_challenge_output()

costs = np.sum((probe_outputs - obs_output_full)**2, 1)

K_est = 32
K_probes = 110

best = np.argmin(costs)
fit_orig_params = probe_inputs[best]

print('Current best guess of params:')
print(' '.join(['%0.12g']*len(fit_orig_params)) % tuple(fit_orig_params))
print('')
print('sq error', costs[best])


for i in range(2,999):
    out_i = i
    out_file = f'PARAMS_stage{i}'
    if not os.path.exists(out_file):
        break
else:
    sys.exit(1)

mask = costs < costs[np.argpartition(costs, K_est)[K_est]]
Sigma = np.cov(probe_inputs[mask].T)
mu = np.mean(probe_inputs[mask], 0)
probes = mu + (np.linalg.cholesky(Sigma) @ np.random.randn(probe_inputs.shape[1], K_probes)).T

# Set up file so next stage will evolve if re-run this script
with open(out_file, 'w') as fid:
    for i, probe in enumerate(probes):
        fid.write("./wrap " + " ".join("%0.12g" % x for x in probe) + f" {i + 1000*out_i}\n")

