from svd_and_squish import *

import equinox as eqx
import jax
import jax.numpy as jnp
import numpy as np

import optax

USE_VELO = True
#USE_VELO = False
if USE_VELO:
    # https://github.com/google/learned_optimization # dependencies pretty hairy and old, not packaged nicely :-(
    from learned_optimization.research.general_lopt import prefab

ntrain = 80000 # XXX increase?
nval = 10000
y_train = jnp.array(svd_targets[:ntrain])
y_val = jnp.array(svd_targets[ntrain:(ntrain+nval)])
x_train = jnp.array(scaled_inputs[:ntrain])
x_val = jnp.array(scaled_inputs[ntrain:(ntrain+nval)])

D = x_train.shape[1]

class PreluResNet(eqx.Module):
    in_layer: eqx.nn.Linear
    out_layer: eqx.nn.Linear
    layers: list
    prelus: list

    def __init__(self, din, dout, dhid, nres_layers, key):
        """layer_sizes includes input and output"""
        kin, kout, key = jax.random.split(key, 3)
        res_keys = jax.random.split(key, nres_layers)
        self.in_layer = eqx.nn.Linear(din, dhid, key=kin)
        self.out_layer = eqx.nn.Linear(dhid, dout, key=kout)
        self.layers = [eqx.nn.Linear(dhid, dhid, key=k) for k in res_keys]
        self.prelus = [eqx.nn.PReLU(jnp.tile(0.25, dhid)) for i in range(nres_layers + 1)]

    def __call__(self, x):
        x = self.prelus[0](self.in_layer(x))
        for layer, prelu in zip(self.layers, self.prelus[1:]):
            x = x + prelu(layer(x))
        return self.out_layer(x)


def loss(model, X, yy):
    pred_y = jax.vmap(model)(X).reshape(yy.shape)
    return jnp.mean((yy - pred_y)**2)

@eqx.filter_jit
def make_step(model, X, yy, opt_state):
    ll, grads = eqx.filter_value_and_grad(loss)(model, X, yy)
    if USE_VELO:
        params, static = eqx.partition(model, eqx.is_array)
        updates, opt_state = optim.update(grads, opt_state, params=params, extra_args={"loss": ll})
    else:
        updates, opt_state = optim.update(grads, opt_state)
    model = eqx.apply_updates(model, updates)
    return ll, model, opt_state

def minibatchify(xx):
    return xx.reshape((-1,100) + xx.shape[1:])

key = jax.random.PRNGKey(0)
model = PreluResNet(D, y_train.shape[1], 100, 15, key)
#model = PreluResNet(D, y_train.shape[1], 5, 1, key) # tiny version for testing
num_epochs = 1000
num_minibatches = minibatchify(y_train).shape[0]
NUM_STEPS = num_minibatches*num_epochs
if USE_VELO:
    optim = prefab.optax_lopt(NUM_STEPS)
elif True:
    schedule = optax.cosine_decay_schedule(init_value=0.001, decay_steps=NUM_STEPS)
    optim = optax.adam(learning_rate=schedule)
else:
    learning_rate = 0.001
    learning_rate = 0.0001
    optim = optax.adam(learning_rate)
params, static = eqx.partition(model, eqx.is_array)
opt_state = optim.init(params)
x_batches = minibatchify(x_train)
y_batches = minibatchify(y_train)
for epoch in range(num_epochs):
    for step, (x, y) in enumerate(zip(x_batches, y_batches)):
        mb_loss, model, opt_state = make_step(model, x, y, opt_state)
        mb_loss = mb_loss.item()
    val_loss = loss(model, x_val, y_val)
    train_loss = loss(model, x_train, y_train)
    print(f"epoch={epoch}, train={train_loss}, val={val_loss}")
    # Shuffle minibatches here.
    k, key = jax.random.split(key, 2)
    idx = jax.random.permutation(k, x_batches.shape[0])
    x_batches = x_batches[idx]
    y_batches = y_batches[idx]

eqx.tree_serialise_leaves("mynet1velo.eqx", model)
