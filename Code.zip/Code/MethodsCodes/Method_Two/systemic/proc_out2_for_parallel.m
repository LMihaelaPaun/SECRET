% run with :
% for a in out/output*.gz ; do echo /usr/bin/octave --norc proc_out2_for_parallel.m $a ; done | parallel -j 10
% hmmm, except octave startup time too long, so need to pass each octave instance multiple files.
% use proc_out_jobs.py

display([argv{1}, '...']);
for i = 1:length(argv)
    path = argv{i};
    basename = path(find(path == '/')+1:end);
    outfile = ['out2/', strrep(basename, '.gz', '.mat')];
    if exist(outfile)
        continue;
    end
    try
        data = load(path);
    catch
        display(['Failed to load ', path]);
    end

    % p - pressure
    % q - flow
    [~,~,p,q,~,~] = gnuplot(data); % extract data
    
    nv = 9; % total no of vessels
    
    ntp = size(p,1); % no of time points in the flow or pressure time series
    
    pressure_all = (p(:,nv+1:2*nv)); % middle prediction all vessels
    flow_all = (q(:,nv+1:2*nv)); % middle prediction all vessels
    
    % competition data consists of flow (entire time series) from vessels 1-7, 
    % and pressure (min and max points only) from vessel 9, 
    % so these are the predictions we save
    pressure_inference  = [max(pressure_all(:,9)), min(pressure_all(:,9))];
    flow_inference = flow_all(:,1:7);

    save('-v7', outfile, 'pressure_inference', 'flow_inference');
end

