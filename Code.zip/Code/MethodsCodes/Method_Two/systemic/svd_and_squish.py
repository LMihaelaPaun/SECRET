"""
Provides scaled inputs and svd-squished outputs, and functions to swap between representations.
"""

import numpy as np
import os as _os

_CACHE_FILE = 'svd_and_squish.npz'

# scale inputs to be in [-1,1]^D box
#              f2   f3   fs2  fs3  alpha
mn = np.array([-45, 2e5, -45, 2e5, 0.85])
mx = np.array([-25, 9e5, -25, 9e5, 0.94])
def scale_params(params):
    return 2.0 * (params - mn) / (mx - mn) - 1.0
def unscale_params(box_params):
    return mn + 0.5 * (box_params + 1.0) * (mx - mn)

if _os.path.exists(_CACHE_FILE):
    cache = np.load(_CACHE_FILE)
    scaled_inputs = cache['scaled_inputs']
    svd_targets = cache['svd_targets']
    mean_output = cache['mean_output']
    VhK = cache['VhK']
    del cache
else:
    data = np.load('simulations.npz')
    inputs = data['inputs']
    outputs = data['outputs']

    scaled_inputs = scale_params(inputs)
    mean_output = outputs.mean(0)

    # Takes ~2 mins. XXX remember will need to add mean_output back on! But makes mean of U zero, which is nice.
    import scipy.linalg as spl
    U, s, Vh = spl.svd(outputs - mean_output, full_matrices=False)

    K = 128
    svd_targets = U[:,:K] * s[:K]

    np.savez_compressed(_CACHE_FILE, scaled_inputs=scaled_inputs, svd_targets=svd_targets, mean_output=mean_output, VhK=Vh[:K])

def reconstruct_output(svd_outputs):
    return svd_outputs @ VhK + mean_output
def transform_output(outputs):
    return (outputs - mean_output) @ VhK.T


# A quick consistency check:
"""
data = np.load('simulations.npz')
inputs = data['inputs']
inputs_recon = unscale_params(scaled_inputs)
assert np.isclose(inputs_recon, inputs).all()

svd_targets_alt = transform_output(outputs)
assert np.isclose(svd_targets, svd_targets_alt).all()

outputs_alt = reconstruct_output(svd_targets)
print(np.sum((outputs - outputs_alt)**2))
# 604.5765453414225
# (Seems big, but is over 100k rows)
"""

