#!/usr/bin/env python3

import numpy as np
import get_challenge_output

MOCK = False

if MOCK:
    data = np.load('simulations.npz')
    inputs = data['inputs']
    outputs = data['outputs']
    obs_output_full = outputs[-1]
    true_params_unscale = inputs[-1]
    true_params = scale_params(inputs[-1])
else:
    obs_output_full = get_challenge_output.get_challenge_output()

import numpy as np
import scipy.io as spio
import matplotlib.pyplot as plt
import scipy.special as spsp
import scipy.stats as spst
import scipy.optimize
import emcee
import os

from quick_assess import *

obs_output = transform_output(obs_output_full)

batch_model = jax.vmap(model)

middle_of_box = np.zeros(x_train[0].shape)
Xmx = np.ones(x_train[0].shape)
Xmn = -np.ones(x_train[0].shape)
width = Xmx - Xmn

def batch_log_pdf(X):
    # Takes (N,D) batch of D-dimensional parameters, I'm going to do all work in [-1,1]^D box and rescale at end, so assume already in that box.
    mask = np.array(np.all((X >= Xmn) & (X <= +Xmx), axis=1))
    #log_probs = np.tile(-np.inf, X.shape[0]) # log-prob is -inf unless inside prior box, and then compute it
    log_probs = np.tile(-1e300, X.shape[0]) # but -inf seems to upsets emcee (even though in FAQ can do it?), so use another extreme value. Get error:
    #   emcee/moves/red_blue.py:99: RuntimeWarning: invalid value encountered in double_scalars
    #   lnpdiff = f + nlp - state.log_prob[j]
    if np.any(mask):
        log_probs[mask] = -0.5*np.sum((batch_model(X[mask]) - obs_output)**2, 1) / obs_variance
    return log_probs

def log_pdf(X):
    # log_pdf of one parameter vector shape (D,).
    # Use if want to try more straightforward/standard emcee usage, without the `pool=NpBatchOpPool()` (which is slower).
    return batch_log_pdf(X[None,:])

def neg_log_pdf(X):
    # For minimizing
    return -batch_log_pdf(X[None,:])

def true_log_pdf(clean_obs, obs_output):
    return -0.5*np.sum((clean_obs_output - obs_output)**2) / obs_variance


class NpBatchOpPool():
    """Pass a member of this class as pool option to emcee-EnsembleSampler.
    The logprob function can then evaluate a (nwalkers/2,ndim) shape batch of examples at a time.
    Makes the computation much faster if fusing the computation of multiple likelihoods is faster."""
    def map(self, fn, x):
        return iter(fn(np.asarray(x)))
    
nwalkers = 200
ndim = width.size

if True:
    # working assumption for now:
    obs_variance = 500

    os.system('date')

    # Initial fit
    opt_out = scipy.optimize.minimize(neg_log_pdf, middle_of_box, bounds=list(zip(Xmn, Xmx)), method='powell')
    fit_params = opt_out.x
    
    # MCMC / annealing
    p0 = fit_params + 0.01 * width * np.random.randn(nwalkers, ndim) # But now use Powell optimization, which works well! (Could use gradient based, but not necessary.)
    p0 = np.minimum(np.maximum(p0, Xmn), Xmx) # keep inside box!
    sampler = emcee.EnsembleSampler(nwalkers, ndim, batch_log_pdf, pool=NpBatchOpPool())
    
    # Hacky strategy regularly re-inits around best point, or emcee can get stuck
    nsteps = 1000
    num_phases = 50
    for phase in range(num_phases):
        for sample in sampler.sample(p0, iterations=nsteps//num_phases):
            obs_variance = obs_variance * 0.99
        p0 = sample.coords[np.argmax(sample.log_prob)] + 1e-3 * np.random.randn(nwalkers, ndim)
        sampler.reset()
        mc_params = sample.coords[np.argmax(sample.log_prob)]
    obs_variance = 1 # for reporting numbers in common way
    if MOCK:
        print('true_params', neg_log_pdf(true_params))
    print('fit_params', neg_log_pdf(fit_params))
    print('mc_params ', neg_log_pdf(mc_params))
    if neg_log_pdf(fit_params) < neg_log_pdf(mc_params):
        best_params = fit_params
    else:
        best_params = mc_params
    test_mse = 0.085212946
    cur_mse = np.mean((model(mc_params) - obs_output)**2)
    obs_variance = max(obs_variance, cur_mse) # XXX BUG sets to 1, had intended to say `test_mse` here. But got reasonable coverage in tests, so don't want to fix at last minute.

    burn_in = 50
    final_steps = 100
    p0 = mc_params + 1e-3 * np.random.randn(nwalkers, ndim)
    state = sampler.run_mcmc(p0, final_steps, progress=False)
    params = sampler.get_chain() # (nsteps, nwalkers, ndim)
    if MOCK:
        samples = params[burn_in::].reshape([-1, params.shape[-1]])
        print("z's", (samples.mean(0) - true_params) / samples.std(0))
    print('-'*75)

    print('Current best guess of params:')
    fit_orig_params = unscale_params(best_params)
    print(' '.join(['%0.12g']*len(fit_orig_params)) % tuple(fit_orig_params))

    probes = params[-1][:110]
    probes[0] = best_params # inject the current best guess so we can see how good it actually is
    probes = unscale_params(probes)
    with open('PARAMS_stage1', 'w') as fid:
        for i, probe in enumerate(probes):
            fid.write("./wrap " + " ".join("%0.12g" % x for x in probe) + f" {i}\n")

os.system('date')
