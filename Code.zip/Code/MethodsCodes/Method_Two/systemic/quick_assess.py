from svd_and_squish import *

import equinox as eqx
import jax
import jax.numpy as jnp
import numpy as np

ntrain = 80000
nval = 10000
y_train = jnp.array(svd_targets[:ntrain])
y_val = jnp.array(svd_targets[ntrain:(ntrain+nval)])
y_test = jnp.array(svd_targets[(ntrain+nval):])
x_train = jnp.array(scaled_inputs[:ntrain])
x_val = jnp.array(scaled_inputs[ntrain:(ntrain+nval)])
x_test = jnp.array(scaled_inputs[(ntrain+nval):])

D = x_train.shape[1]

class PreluResNet(eqx.Module):
    in_layer: eqx.nn.Linear
    out_layer: eqx.nn.Linear
    layers: list
    prelus: list

    def __init__(self, din, dout, dhid, nres_layers, key):
        """layer_sizes includes input and output"""
        kin, kout, key = jax.random.split(key, 3)
        res_keys = jax.random.split(key, nres_layers)
        self.in_layer = eqx.nn.Linear(din, dhid, key=kin)
        self.out_layer = eqx.nn.Linear(dhid, dout, key=kout)
        self.layers = [eqx.nn.Linear(dhid, dhid, key=k) for k in res_keys]
        self.prelus = [eqx.nn.PReLU(jnp.tile(0.25, dhid)) for i in range(nres_layers + 1)]

    def __call__(self, x):
        x = self.prelus[0](self.in_layer(x))
        for layer, prelu in zip(self.layers, self.prelus[1:]):
            x = x + prelu(layer(x))
        return self.out_layer(x)

def loss(model, X, yy):
    pred_y = jax.vmap(model)(X).reshape(yy.shape)
    return jnp.mean((yy - pred_y)**2)

def each_square_error(model, X, yy):
    pred_y = jax.vmap(model)(X).reshape(yy.shape)
    return jnp.sum((yy - pred_y)**2, 1)

key = jax.random.PRNGKey(0)
model = PreluResNet(D, y_train.shape[1], 100, 15, key)
model = eqx.tree_deserialise_leaves("mynet1velo.eqx", model)

# Some notes
"""
from sklearn.linear_model import LinearRegression
from sklearn.kernel_approximation import RBFSampler
rbf_feature = RBFSampler(gamma=0.1, random_state=1, n_components=4000)
Phi_train = rbf_feature.fit_transform(x_train)
Phi_val = rbf_feature.fit_transform(x_val)
reg2 = LinearRegression().fit(Phi_train, y_train)
model2 = lambda x: reg2.predict(rbf_feature.fit_transform(x.reshape(1,-1)))

# If using noise variance of ~500, which I think plausible (roughly 0.1 of original marginal signal variance?) then simulated outputs that are closest are ~1 nat apart (maybe 0.5 nats apart), so there is another sim that's roughly plausibly the source of some data?
idx2 = np.argmin(np.sum((y_train - y_val[0])**2, 1))
np.sum((y_train[idx2] - y_val[0])**2)
# Array(530.229, dtype=float32)
# If replace simulator with equinox model, then model comparison barely changes (sq error wrong by 4, but if divide by ~500 then not a perceivable model difference):
np.sum((model(x_train[idx2]) - model(x_val[0]))**2)
# Array(534.0118, dtype=float32)
# But if replace with rbf model, error is now enough to swing model comparison; expect it to upset the posterior noticably.
# Could be ok if do correction step, but by itself isn't going to be a passable surrogate.
np.sum((model2(x_train[idx2]) - model2(x_val[0]))**2)
# 1596.0873052550737

# What are relative square errors like, for comparison with fitting square error directly:
y_val_pred = jax.vmap(model)(x_val)
se_val_pred = np.sum((y_val_pred - y_test[0])**2, 1)
se_val_true = np.sum((y_val - y_test[0])**2, 1)
(np.abs(se_val_pred - se_val_true) / se_val_true).mean()
# Array(0.00291132, dtype=float32)
#
# For comparison, a quick 100 epoch fit of scalar sq error (with cosine schedule) got:
# Array(0.0075, dtype=float32)
# So better here, but fitted model much more carefully.

# Back to original velo model on high-dim output, on train set:
y_train_pred = jax.vmap(model)(x_train)
se_train_pred = np.sum((y_train_pred - y_test[0])**2, 1)
se_train_true = np.sum((y_train - y_test[0])**2, 1)
(np.abs(se_train_pred - se_train_true) / se_train_true).mean()
# Array(0.00229636, dtype=float32)
# Similar, so not a big overfiting problem on this measure.
# If fit scalar model longer might see more generalization problems there, or might be similar?

"""
