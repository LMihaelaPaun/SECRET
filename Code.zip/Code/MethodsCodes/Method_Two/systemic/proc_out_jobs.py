#!/usr/bin/env python3

# ./proc_out_jobs.py | parallel -j 10

import glob, re, os

def not_done(filename):
    fid = re.match(r'.*_([0-9]*).2d.gz', filename).groups()[0]
    return not os.path.exists(f'out2/output_{fid}.2d.mat')

all_files = glob.glob('out/output_*.2d.gz')
all_files = [x for x in all_files if not_done(x)]
start = 0
inc = 100

while start < len(all_files):
    stop = start + inc
    print('nice /usr/bin/octave --norc proc_out2_for_parallel.m', ' '.join(all_files[start:stop]))
    start = stop
