#!/usr/bin/env python3

import numpy as np

N = 100000

#              f2   f3   fs2  fs3  alpha
mn = np.array([-45, 2e5, -45, 2e5, 0.85])
mx = np.array([-25, 9e5, -25, 9e5, 0.94])

D = mn.size
params = mn + np.random.rand(N, D) * (mx - mn)[None,:]

for i, p in enumerate(params):
    print("./wrap", " ".join("%g" % x for x in p), i)

