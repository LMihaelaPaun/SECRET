#!/usr/bin/env python3

import numpy as np
import scipy.io as spio

import glob, re

def unwrap_outputs(data):
    #keys = sorted([x for x in data.keys() if not x.startswith('_')]) # general/'clever' but harder for me to see what I have
    keys = ('pressure_inference', 'flow_inference') # First two values are the min/max pressure, then 7 flow time series
    return np.concatenate([data[k].T.ravel() for k in keys]) # The .T is to keep time-series together, concatenated one after the other, rather than interleaved. For plotting output easily

inputs = []
outputs = []

output_mats = glob.glob('out2/output_*.2d.mat')
for mat in output_mats:
    job_str = re.match(r'.*_(.*).2d.mat', mat).groups()[0]
    data = spio.loadmat(mat)
    params = np.loadtxt(f'out/params_{job_str}')
    assert(params[-1] == int(job_str))
    params = params[:-1]
    inputs.append(params)
    outputs.append(unwrap_outputs(data))

inputs = np.array(inputs)
outputs = np.array(outputs)

np.savez_compressed('simulations_probes.npz', inputs=inputs, outputs=outputs)

