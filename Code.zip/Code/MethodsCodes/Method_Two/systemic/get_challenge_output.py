def get_challenge_output():
    import numpy as np
    pressures = np.loadtxt('../../data_release/SystemicData/SystFilePressure.txt')
    flows_all = np.loadtxt('../../data_release/SystemicData/SystFileFlow.txt')
    obs_output_full = np.hstack([pressures.ravel(), flows_all.T.ravel()])
    obs_output_full[:2] = obs_output_full[1::-1] # XXX swap min/max pressures to match how simulator was processed by proc_out2_for_parallel.m (based on competition-provided code)
    return obs_output_full

