

import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3' 
import numpy as np
import matplotlib.pyplot as plt
import sys
import tensorflow as tf
import tensorflow_probability as tfp
import KronGP as kgp
from scipy import stats

print(sys.version, flush=True)


print(tf.config.list_physical_devices(device_type='GPU'))
print("Num GPUs Available: ", len(tf.config.list_physical_devices('GPU')))
tf.keras.backend.set_floatx('float64')
gpus = tf.config.experimental.list_physical_devices('GPU')
np.set_printoptions(suppress=True)
eps = np.finfo(float).eps

## MODEL SETTINGS

xKernel = "Matern52"
tKernel = "Matern52"
noise = .1
train_set_size = 500

print(f"Model arguments are:")
print(f"xKernel:", xKernel)
print(f"tKernel:", tKernel)
print(f"Noise:", noise)
print(f"Train set size:", train_set_size)

# %% Loading in data

X = np.loadtxt("Data/_data_goes_here_") ## space-filling design 
features = X.shape[1]

minVec = np.array([-45, 2e5, -45, 2e5, 0.85])
maxVec = np.array([-25, 9e5, -25, 9e5, 0.94])

def NormaliseVector(vec):
    return (vec - minVec)/(maxVec - minVec)

def UnnormaliseVector(vec):
    return (vec)*(maxVec - minVec) + minVec

Xtrain = X[:train_set_size]
Xtrain = NormaliseVector(Xtrain)

Xtest = X[-500:]
Xtest = NormaliseVector(Xtest)

ModelList = [1, 2, 3, 4, 5, 6, 7]

InferenceRange = 512
t = np.arange(0, InferenceRange, 1, dtype=np.float64)[:, None]


Ytest = {}
GPDict = {}
for model in ModelList:
    Y = np.loadtxt(f"Data/_simulator_output_")
    Ytrain = Y[:train_set_size]
    Ytest[str(model)] = Y[-500:]
    GPDict[str(model)] = kgp.KronGP(Xtrain, t, Ytrain, xKernel,
                                    tKernel, noise=noise)
    GPDict[str(model)].optimiser(200)

del X, Y

#%%

## Load in comp data:

CompData = np.loadtxt("Data/SystFileFlow.txt").T

CompDataFlat = CompData.flatten()[None, :]


#%%

def RMSE_func(input1, input2):
    sumsquared = (input1 - input2)**2
    return tf.math.sqrt(tf.reduce_sum(sumsquared, 1) / tf.cast(tf.shape(input2)[1], tf.float64))

def predictMeans(params):
    params = NormaliseVector(params)
    out = tf.concat([GPDict[str(mod)].predict(params) for mod in ModelList], 1)
    return out

bijector = tfp.bijectors.Sigmoid(minVec, maxVec)
inv_bijector = bijector.inverse

def objective(params, data):
    out = predictMeans(params)
    return RMSE_func(out, data)

RMSE = np.array([tf.math.reduce_mean(RMSE_func(GPDict[str(i)].predict(Xtest), Ytest[str(i)])) for i in ModelList])
print(RMSE)


#%%


def tracefn(traceable_quantities):
    out = traceable_quantities
    print(f"Step {out.step}: {out.loss.numpy().round(3)}", end="\r", flush=True)
    return out.loss, out.parameters

schedule = tf.keras.optimizers.schedules.CosineDecay(
    1e-1, 200, .1, name=None
)

def OptimiseRMSE(initialVals, nsteps = 300, objective=objective):
    x = tf.Variable(initialVals)
    minAdam = tfp.math.minimize(
        lambda: objective(bijector(x), tf.constant(CompDataFlat)),
        nsteps,
        optimizer=tf.keras.optimizers.Adam(learning_rate=schedule,
                                        epsilon=1e-4,
                                        ),        

        trace_fn = lambda input: tracefn(input),
        trainable_variables = [x],
    )
    minOutput = minAdam[0]
    findMin = -1

    MinVals = bijector(minAdam[1][0][findMin]).numpy()
    MinObj = minOutput[findMin].numpy()
    return MinVals, MinObj

#%%


def randomStart():
    start = stats.uniform.rvs(minVec, (maxVec - minVec))
    return start

def parallelStartPoints(num_parallel_iters = 1):
    return np.array([randomStart() for i in range(num_parallel_iters)])

def ParallelProc(num_parallel_iters, nsteps=300):
    return OptimiseRMSE(inv_bijector(parallelStartPoints(num_parallel_iters)), nsteps)

ParallelProc(2)


#%%

