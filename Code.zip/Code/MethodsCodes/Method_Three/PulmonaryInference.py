
#%%

import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3' 
import numpy as np
import matplotlib.pyplot as plt
import sys
from scipy.spatial.distance import cdist
import tensorflow as tf
import tensorflow_probability as tfp
import KronGP as kgp
import pymc as pm
import pytensor.tensor as at
import arviz as az
from pytensor.compile.ops import as_op
import seaborn as sns
from scipy import stats

#%%

print(sys.version, flush=True)


print(tf.config.list_physical_devices(device_type='GPU'))
print("Num GPUs Available: ", len(tf.config.list_physical_devices('GPU')))
tf.keras.backend.set_floatx('float64')
gpus = tf.config.experimental.list_physical_devices('GPU')
np.set_printoptions(suppress=True)
eps = np.finfo(float).eps

FileID = "local"

## MODEL SETTINGS

xKernel = "Matern52"
tKernel = "Matern52"
noise = .1
train_set_size = 5000

print(f"Model arguments are:")
print(f"xKernel:", xKernel)
print(f"tKernel:", tKernel)
print(f"Noise:", noise)
print(f"Train set size:", train_set_size)

# %% Loading in data

X = np.loadtxt("Data/_data_goes_here_") ## space-filling design 
features = X.shape[1]

minVec = np.array([9e4, .83, 20, 20])
maxVec = np.array([3e5, .89, 50, 50])

def NormaliseVector(vec):
    return (vec - minVec)/(maxVec - minVec)

def UnnormaliseVector(vec):
    return (vec)*(maxVec - minVec) + minVec

X = NormaliseVector(X)

Xtrain = X[:train_set_size]
Xtest = X[-500:]

ModelList = ["MPA", "LSV", "RSV"]

InferenceRange = 512

t = np.arange(0, InferenceRange, 1, dtype=np.float64)[:, None]

#%%

Ytest = {}
GPDict = {}
for model in ModelList:
    Y = np.loadtxt(f"Data/_simulator_output_")
    Ytrain = Y[:train_set_size]
    Ytest[str(model)] = Y[-500:]
    GPDict[str(model)] = kgp.KronGP(Xtrain, t, Ytrain, xKernel,
                                    tKernel, t_ls=60., noise=noise, dtype=tf.float64)
    GPDict[str(model)].optimiser(200)

del X, Y

#%% Load in comp data:

PressureData = np.loadtxt("Data/PressureData3.txt")
FlowData = np.loadtxt("Data/FlowData3.txt")
FlowLSV = FlowData[:,0]
FlowRSV = FlowData[:,1]

CompData = PressureData.reshape((1, len(PressureData)))
CompData = np.append(CompData, FlowLSV.reshape((1, len(PressureData))), 0)
CompData = np.append(CompData, FlowRSV.reshape((1, len(PressureData))), 0)

CompDataFlat = CompData.flatten()[None, :]


def RSS_func(input1, input2):
    sumsquared = (input1 - input2)**2
    return tf.math.sqrt(tf.reduce_sum(sumsquared, 1) / tf.cast(tf.shape(input2)[1], tf.float64))

def predictMeans(params):
    params = NormaliseVector(params)
    out = tf.concat([GPDict[str(mod)].predict(params)[:, tf.newaxis, :] for mod in ModelList], 1)
    return out

def objective(params, data):
    out = predictMeans(params)
    return RSS_func(out, data)

for mod in ModelList:
    print(tf.math.reduce_mean(RSS_func(GPDict[mod].predict(Xtest), Ytest[mod])))

#%% 

### Auxiliary functions 

ti = tf.cast(np.linspace(0, 0.85, 512, dtype=np.float64).reshape((512, 1)), tf.float64)

bijector = tfp.bijectors.Sigmoid(np.append(minVec, np.array([0., 0.])), 
                                 np.append(maxVec, np.array([0.85,22.5]))
                                 )
inv_bijector = bijector.inverse

def randomStart():
    start = stats.uniform.rvs(minVec, maxVec-minVec)
    ls_sigma_start = stats.uniform.rvs(np.array([0, 0]), np.array([.85, 22.5]))
    return np.append(start, ls_sigma_start)

def RandomStarts(numStarts = 1):
    return tf.cast((np.array([randomStart() for i in range(numStarts)])), tf.float64)

ti = np.linspace(0, 0.85, 512).reshape((512, 1))
rMat = cdist(ti, ti, 'euclidean')
sqrt3 = tf.cast(tf.math.sqrt(3.)*rMat, tf.float64)

def target_LL(param_vector, data = CompData, temp = 1.):
    physiologicalParams = param_vector[:, :features]
    ls = param_vector[:, -2]
    sigma = param_vector[:, -1]
    temp_ti = ti[tf.newaxis ,:, :]/ls[:, tf.newaxis, tf.newaxis]
    sqrt3 = np.sqrt(3.0)
    rMat = tf.sqrt(tf.reduce_sum((((((temp_ti[:, :, tf.newaxis, :] - temp_ti[:, tf.newaxis])) ))**2.), axis=-1))
    sqrt3r = sqrt3*rMat
    covMat = sigma[:, tf.newaxis, tf.newaxis] * (tf.cast(1.0, tf.float64) + sqrt3r) * tf.math.exp(-sqrt3r) + tf.cast(1e-6*tf.eye(512), tf.float64)[tf.newaxis, :, :]
    mu = predictMeans(physiologicalParams)
    y1 = (data[tf.newaxis, :, :]- mu) @ tf.linalg.inv(covMat) 
    norm = tf.math.reduce_sum(tf.math.multiply( y1, data[tf.newaxis, :, :]- mu), -1)
    return -0.5*tf.reduce_sum( tf.linalg.logdet(covMat)[:, None] + norm + tf.cast(512., tf.float64)*tf.cast(tf.math.log(2.*np.pi), tf.float64) , -1)*temp

def ll_and_grads(input): # For debugging
    return tfp.math.value_and_gradient(lambda inp: target_LL(inp),
                                  input)


def tracefn(traceable_quantities):
    out = traceable_quantities
    print(f"Step {out.step}, nll {out.loss.numpy()}", end="\r", flush=True)
    return out.loss, out.parameters

def MAP_search(initialVals, nsteps = 200):
    x = tf.Variable(inv_bijector(initialVals))
    minAdam = tfp.math.minimize(
        lambda: -1.*target_LL(bijector(x)),
        nsteps,
        optimizer=tf.keras.optimizers.Adam(learning_rate=0.1,
                                           epsilon=1e-4,
                                           ),        

        trace_fn = lambda input: tracefn(input),
        trainable_variables = [x],
    )
    minOutput = minAdam[0]
    findMin = -1

    MinVals = bijector(minAdam[1][0][findMin]).numpy()
    MinObj = minOutput[findMin].numpy()
    return MinVals, MinObj

MAP = MAP_search(RandomStarts(4), 300)
print(MAP)


#%% 

### pymc Inference

@as_op(itypes=[at.dscalar, at.dscalar, at.dscalar, at.dscalar],
        otypes=[at.dmatrix])
def GPprediction(kMV, alpha, lA, lV):
    ParamVec = np.array([kMV, alpha, lA, lV])[None]
    return predictMeans(NormaliseVector(ParamVec)).numpy().reshape((3, 512))

@as_op(itypes=[at.dscalar, at.dscalar],
        otypes=[at.dmatrix])
def CovMat32(l, sigM):
    sqrtr = np.sqrt(3)*rMat/l
    return sigM * (1 + sqrtr) * np.exp(-sqrtr) + 1e-6*np.eye(512)

#%%

InitValues = np.array([2.5e5, 0.885, 34, 25, 0.1, 7.87])

InitDict = {"kMV": InitValues[0],
                "alpha": InitValues[1],
                "lA": InitValues[2],
                "lV": InitValues[3],
                "ls": InitValues[-2],
                "sigma": InitValues[-1]}

print(f"Running on PyMC v{pm.__version__}")

numDraws = 2000
tune = 2000
numChains = 1

decay_model = pm.Model()

with decay_model:
    kMV = pm.Uniform("kMV", lower=9e4, upper=3e5, initval=250000.,)
    alpha = pm.Uniform("alpha", lower=0.83, upper=0.89, initval=0.885,)
    lA = pm.Uniform("lA", lower=20, upper=50, initval=35.,)
    lV = pm.Uniform("lV", lower=20, upper=50, initval= 25,)
    ls = pm.Uniform("ls", lower=0, upper=0.85, initval= 0.1 ,)
    sigma = pm.Uniform("sigma", lower=0, upper=22.5, initval=5.8,)

    mu = GPprediction(kMV, alpha, lA, lV)
    cov = CovMat32(ls, sigma)
    Y_obs = pm.MvNormal("Y_obs", mu=mu, cov=cov, observed=CompData)

    idata = pm.sample(draws = numDraws, tune=tune, step = pm.DEMetropolisZ(tune="scaling", proposal_dist=pm.NormalProposal),
    cores = 1, chains=numChains, idata_kwargs=dict(log_likelihood=False), discard_tuned_samples=False)

print(az.summary(idata))
az.plot_trace(idata)
plt.clf()

samples = np.array(idata.posterior.to_array()[:,0,:].T)
num_samples = len(samples)
if numChains>1:
    for i in range(numChains-1):
        samples = np.append(samples, idata.posterior.to_array()[:,i+1,:].T, 0)

#%%
        
#np.savetxt(f"pymcSample{FileID}.txt", samples)

g_truth = np.array([2.5e5, 0.885, 35, 25, 0.1, 5.8])
paramNames = ["kMV", "alpha", "lA", "lV", "GP lengthscale", "GP amplitude"]

colors = ['b', 'g', 'r', "orange", "y", "c"]

num_samples = len(samples)

def TracePlots(x):
    for i in range(len(paramNames)):
        plt.subplot(3, 2, i+1)
        plt.plot(x[:,i], c=colors[i], alpha=.3, label=paramNames[i])
        plt.hlines(g_truth[i], 0, len(x), zorder=4, color=colors[i])
        plt.legend(loc='upper right')
        
    plt.show()
    plt.figure(figsize=(6,4))
    for i in range(len(paramNames)):
        plt.subplot(3, 2, i+1)
        if i == 0:
            plt.ticklabel_format(style='sci', axis='x', scilimits=(0,0))
        sns.kdeplot(x[:,i], color="red", alpha=0.5, bw_adjust=1, label="Post competition")
        if i == 0:
            plt.ticklabel_format(style='sci', axis='x', scilimits=(0,0))
        plt.ylabel(paramNames[i])
        ymax = plt.ylim()[1]
        plt.vlines(g_truth[i], 0, ymax, color="0.4")
        plt.ylim(0, ymax)
    plt.show()

TracePlots(samples)



#%%

