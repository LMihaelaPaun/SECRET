
import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3' 
import numpy as np
import tensorflow as tf
import tensorflow_probability as tfp

bijector = tfp.bijectors.Softplus()
inv_bijector = bijector.inverse

def tfRBF(var, lengthscale, X1, X2=None, grad=False):
    var, lengthscale = bijector(var), bijector(lengthscale)
    if X2 is None:
        X2= X1
    ls = tf.cast(lengthscale, tf.float64)
    variance = tf.cast(var, tf.float64)
    r = (tf.reduce_sum(((X1[:, tf.newaxis, :] - X2) ** 2. )/ ((ls**2.)), axis=-1))
    K = variance *  tf.math.exp(-0.5 * r)
    if grad:
        sqrtr = tf.math.sqrt(r)
        return K, -(sqrtr)*K, sqrtr
    return K

def tfMat52True(var, X1, X2=None, grad=False):
    if X2 is None:
        X2= X1
    r = tf.sqrt(tf.reduce_sum((((((X1[:, tf.newaxis, :] - X2)) ))**2.), axis=-1))
    sqrt5 = np.sqrt(5.0)
    K = var * (1.0 + sqrt5 * r + 5.0 / 3.0 * tf.square(r)) * tf.exp(-sqrt5 * r)
    if grad:
        dK_dr = var*(10./3.*r -5.*r -5.*sqrt5/3.*r**2.)*np.exp(-sqrt5*r)
        return K, dK_dr, r
    return K

def tfMat52(var, lengthscale, X1, X2=None, grad=False):
    var, lengthscale = bijector(var), bijector(lengthscale)
    X1scaled = X1/lengthscale
    X2scaled = X2/lengthscale
    return tfMat52True(var, X1scaled, X2scaled, grad)


def tfMat32True(var, X1, X2=None, grad=False):
    r = tf.sqrt(tf.reduce_sum((((((X1[:, tf.newaxis, :] - X2)) ))**2.), axis=-1))
    sqrt3 = np.sqrt(3.0)
    K = var * (1.0 + sqrt3 * r ) * tf.exp(-sqrt3 * r)
    if grad:
        dK_dr = -3.*var*r*np.exp(-sqrt3*r)
        return K, dK_dr, r
    return K

def tfMat32(var, lengthscale, X1, X2=None, grad=False):
    X1scaled = X1/lengthscale
    X2scaled = X2/lengthscale
    return tfMat32True(var, X1scaled, X2scaled, grad)

kernelsDict = {"RBF": tfRBF,
            "Matern52": tfMat52,
            "Matern32": tfMat32,}



class KronGP:
    def __init__(self, X, t, Y, xkern, tkern, 
                 x_var = 1., x_ls = None, 
                 t_var = 1., t_ls = None, noise = 1.,
                 dtype = tf.float64):
        self.dtype = dtype
        if dtype == tf.float32:
            self.jitter = 1e-8
        else:
            self.jitter = 1e-11
        self.n, self.m = np.shape(Y)
        self.features = np.shape(X)[1]
        self.X = tf.cast(X, self.dtype)
        self.Y = tf.cast(Y, self.dtype)
        self.t = tf.cast(t, self.dtype)
        self.xkern = kernelsDict[xkern]
        self.x_var = tf.Variable(x_var, dtype=self.dtype)
        if x_ls is None:
            x_ls = np.repeat(1., self.features)
        self.x_ls = tf.Variable(x_ls, dtype=self.dtype)
        self.tkern = kernelsDict[tkern]
        self.t_var = tf.Variable(t_var, dtype=self.dtype)
        if t_ls is None:
            t_ls = 1.
        self.t_ls = tf.Variable(t_ls, dtype=self.dtype)
        self.noise = tf.Variable(noise, dtype=self.dtype)
        self.nmlogpi = tf.cast(0.5 * self.n * self.m * np.log(2.*np.pi), self.dtype)

    def loglikelihood(self):
        KX = self.xkern(self.x_var, self.x_ls, self.X, self.X)
        KT = self.tkern(self.t_var, self.t_ls, self.t, self.t)
        s2, u2 = tf.linalg.eigh(KT) 
        s1, u1 = tf.linalg.eigh(KX) 
        W = tf.experimental.numpy.kron(s2, s1) + bijector(self.noise) 
        Y_ = tf.linalg.matmul(tf.transpose(u1), tf.linalg.matmul(self.Y, u2))
        Wi = 1./W
        Wi = tf.expand_dims(Wi, 1)
        Ytilde = tf.reshape(tf.transpose(Y_),[tf.shape(Wi)[0], 1])*Wi
        output = -(0.5*tf.math.reduce_sum(tf.math.log(W)) 
            +0.5*tf.linalg.matmul((tf.reshape(tf.transpose(Y_), [1, tf.shape(Wi)[0]])), Ytilde) 
            + self.nmlogpi)

        return output

    def _trace_fn(self, traceable_quantities):
        print(traceable_quantities.step, traceable_quantities.loss, end="\r", flush=True)
        return [traceable_quantities.loss, traceable_quantities.parameters]

    def optimiser(self, nsteps = 100, learn_rate = 0.1):
        result = tfp.math.minimize(
            loss_fn = lambda: -self.loglikelihood(),
            num_steps = nsteps,
            optimizer = tf.keras.optimizers.Adam(learning_rate=learn_rate),
            trace_fn = self._trace_fn
        )
        self._pred_values()
        return result

    def _pred_values(self):

        KX = self.xkern((self.x_var), (self.x_ls), self.X, self.X)
        self.KT = self.tkern(self.t_var, self.t_ls, self.t, self.t)
        s2, self.u2 = tf.linalg.eigh(self.KT) 
        s1, self.u1 = tf.linalg.eigh(KX)
        W = tf.experimental.numpy.kron(s2, s1) + bijector(self.noise)
        Y_ = tf.linalg.matmul(tf.transpose(self.u1), tf.linalg.matmul(self.Y, self.u2))
        Wi = 1./W
        Wi = tf.expand_dims(Wi, 1)
        Ytilde = tf.reshape(tf.transpose(Y_),[tf.shape(Wi)[0], 1])*Wi
        self.Wi, self.Ytilde = Wi, Ytilde
        self.KinvY_full = self.u1@tf.transpose(tf.reshape(Ytilde, [self.m, self.n]))@tf.transpose(self.KT@self.u2)
        self.KinvY = self.u1@tf.transpose(tf.reshape(Ytilde, [self.m, self.n]))@tf.transpose(self.u2)
        return self.KinvY_full
    
    def predict(self, xnew, t_pred = None, var = False):
        KxX = self.xkern(self.x_var, self.x_ls, xnew, self.X)
        if t_pred is None:
            mu = KxX @ self.KinvY_full
            if var:
                A = KxX @ self.u1
                B = self.KT @ self.u2
                kxx_diag = tf.linalg.diag_part(self.xkern(self.x_var, self.x_ls, xnew, xnew))
                kT_diag = tf.linalg.diag_part(self.KT)
                BA = tf.experimental.numpy.kron(B, A)
                variance = tf.experimental.numpy.kron(kT_diag, kxx_diag) - tf.math.reduce_sum(BA**2 * self.Wi, 1) + bijector(self.noise)
                return mu, variance
            return mu
        else:
            KtT = self.tkern(self.t_var, self.t_ls, t_pred, self.t)
            mu = KxX @ (self.KinvY @ tf.transpose(KtT))
            if var:
                A = KxX @ self.u1
                B = KtT @ self.u2
                kxx_diag = tf.linalg.diag_part(self.xkern(self.x_var, self.x_ls, xnew, xnew))
                kT_diag = tf.linalg.diag_part(self.tkern(self.t_var, self.t_ls, t_pred, t_pred))
                BA = tf.experimental.numpy.kron(B, A)
                variance = tf.experimental.numpy.kron(kT_diag, kxx_diag) - tf.math.reduce_sum(BA**2 * self.Wi, 1) + bijector(self.noise)
                return mu, variance
            return mu 