The folder “Assessment” contains the assessment criteria for both systemic and pulmonary models.
Main scripts: Assessment_pulmonary .m (in Pulmonary sub-folder), Assessment_systemic.m (in Systemic sub-folder) employing criteria described in Section 6 of the paper, and producing results presented in Section 7.
