%%%% Pulmonary model: assessment

clear; close all

% path to participants' entries
addpath(genpath('CompetitionEntries'))

% path to competition data
addpath(genpath('CompetitionData'))

% path to systemic simulator
addpath(genpath('PulmonaryModel/Code'))

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Load parameter estimates

MetOne_parEstimate = csvread('/CompetitionEntries/Pulmonary/MetOne_estimate_pulm.csv', 1, 0);
MetTwo_parEstimate = importdata('/CompetitionEntries/Pulmonary/MetTwo_estimate_pulm.txt'); MetTwo_parEstimate = MetTwo_parEstimate';
MetThree_parEstimate = importdata('/CompetitionEntries/Pulmonary/MetThree_estimate_pulm.txt'); MetThree_parEstimate = MetThree_parEstimate(1:end-2)';

estimate_simulator_meanPost = 10^5*[2.510026172740015,0.000008860551849,...
    0.000345027728918,0.000249893466077];

% Call fluids model AFTER EDITING THE MAKEFILE (instructions in
% /PulmonaryModel/Makefile_Instructions)
cd('/PulmonaryModel/Code')
!make clean
!make

% no of time points in the time series
ntp = 512;

num_ves = 27;   % Number of large vessels in the tree

art     = 1:15; % Arteries
ven     = 16:27;% Veins

file_id = 1;

[MetOne_pressureEstimate, MetOne_flowEstimate] = Run_fluidsModel(MetOne_parEstimate, ...
    file_id, num_ves, art, ven, ntp);

[MetTwo_pressureEstimate, MetTwo_flowEstimate] = Run_fluidsModel(MetTwo_parEstimate, ...
    file_id, num_ves, art, ven, ntp);

[MetThree_pressureEstimate, MetThree_flowEstimate] = Run_fluidsModel(MetThree_parEstimate, ...
    file_id, num_ves, art, ven, ntp);

[pressureEstimate_simulator_meanPost, flowEstimate_simulator_meanPost] = ...
     Run_fluidsModel(estimate_mine_meanPost, file_id, num_ves, art, ven, ntp);

%% load competition data
load('/CompetitionData/PulmonaryData/PulmonaryModel_CompetitionData.mat')

%% Load samples
cd('/Assessment/Pulmonary')

% simulator-based
load('/Assessment/Pulmonary/Simulator_results_pulm.mat')

% participants'
MetOne_samples = csvread('/CompetitionEntries/Pulmonary/MetOne_pulm.csv', 1, 0);
MetTwo_samples_all = importdata('/CompetitionEntries/Pulmonary/MetTwo_pulmonary_samples_with_hypers.txt');
MetTwo_samples = MetTwo_samples_all(:,3:end);

MetThree_samples = importdata('/CompetitionEntries/Pulmonary/MetThree_pulm.txt');

MetTwo_largeModel_samples_all = importdata('/CompetitionEntries/Pulmonary/MetTwo_large_model_pulmonary_samples_with_hypers.txt');
MetTwo_largeModel_samples = MetTwo_largeModel_samples_all(:,3:end);

MetThree_postComp_samples = importdata('/CompetitionEntries/Pulmonary/MetThree_PostCompPulmonarySample.txt');

%%% plotting
% 1D kernel density plots
figure(20);clf(20)
for i=1:4
    subplot(2,2,i);hold on;
    [f,xi] = ksdensity(MetOne_samples(:,i));
    plot(xi,f, '-b', 'linewidth', 3);
    set(gca, 'fontsize', 30); axis tight
    
    %
    [f,xi] = ksdensity(MetTwo_samples(:,i));
    plot(xi,f, '-c', 'linewidth', 3);
    set(gca, 'fontsize', 30); axis tight
    
    %
    [f,xi] = ksdensity(MetThree_samples(:,i));
    plot(xi,f, '--r', 'linewidth', 3);
    set(gca, 'fontsize', 30); axis tight
    yticks([min(f) max(f)])
    ytickformat('%.1g')
    %
    [f,xi] = ksdensity(samples_simulator(:,i));
    plot(xi,f, '--k', 'linewidth', 3);
    set(gca, 'fontsize', 30); axis tight
    
    if i==1
        title('f_3^{MV}')
    elseif i==2
        title('\alpha')
    elseif i==3
        title('lrr_A')
    else
        title('lrr_V')
    end
    
end

legend('Method I', 'Method II', 'Method III', 'simulator')

% MetTwo competition versus MetTwo large model
figure(21);clf(21)
for i=1:4
    subplot(2,2,i);hold on;
    [f,xi] = ksdensity(MetTwo_samples(:,i));
    plot(xi,f, '-c', 'linewidth', 3);
    set(gca, 'fontsize', 30); axis tight
    if i==1
        yticks([min(f) max(f)])
        ytickformat('%.1g')
    end
    %
    [f,xi] = ksdensity(MetTwo_largeModel_samples(:,i));
    plot(xi,f, '-g', 'linewidth', 3);
    set(gca, 'fontsize', 30); axis tight
    if i==2
        yticks([min(f) max(f)])
        ytickformat('%.1g')
    end
    %
    [f,xi] = ksdensity(samples_simulator(:,i));
    plot(xi,f, '--k', 'linewidth', 3);
    set(gca, 'fontsize', 30); axis tight
    if i==3||i==4
        yticks([min(f) max(f)])
        ytickformat('%.1g')
    end
    
    if i==1
        title('f_3^{MV}')
    elseif i==2
        title('\alpha')
    elseif i==3
        title('lrr_A')
    else
        title('lrr_V')
    end
    
end

legend('Method II comp', 'Method II post-comp', 'simulator')%, '

% MetThree competition versus MetThree large model
figure(22);clf(22)
for i=1:4
    subplot(2,2,i);hold on;
    [f,xi] = ksdensity(MetThree_samples(:,i));
    plot(xi,f, '-r', 'linewidth', 3);
    set(gca, 'fontsize', 30); axis tight
    if i==1||i==2
        yticks([min(f) max(f)])
        ytickformat('%.1g')
    end
    %
    [f,xi] = ksdensity(MetThree_postComp_samples(:,i));
    plot(xi,f, '-g', 'linewidth', 3);
    set(gca, 'fontsize', 30); axis tight
    if i==3||i==4
        yticks([min(f) max(f)])
        ytickformat('%.1g')
    end
    %
    [f,xi] = ksdensity(samples_simulator(:,i));
    plot(xi,f, '--k', 'linewidth', 3);
    set(gca, 'fontsize', 30); axis tight
    
    if i==1
        title('f_3^{MV}')
    elseif i==2
        title('\alpha')
    elseif i==3
        title('lrr_A')
    else
        title('lrr_V')
    end
    
end

legend('Method III comp', 'Method III post-comp', 'simulator')%, '

%
%
%% Now run fluids model (simulator) for all samples

cd('/PulmonaryModel/Code')

Ns = size(samples_simulator,1); % no of samples

MetOne_pressure = NaN(Ns,ntp); MetOne_flow = NaN(Ns,ntp,2);
MetTwo_pressure = NaN(Ns,ntp); MetTwo_flow = NaN(Ns,ntp,2);
MetThree_pressure = NaN(Ns,ntp); MetThree_flow = NaN(Ns,ntp,2);

nrun=20;
delete(gcp('nocreate'))
parpool('local', nrun)

parfor i=1:Ns
    [MetOne_pressure(i,:), MetOne_flow(i,:,:)] = Run_fluidsModel(MetOne_samples(i,:), ...
        i, num_ves, art, ven, ntp);
end

parfor i=1:Ns
    [MetTwo_pressure(i,:), MetTwo_flow(i,:,:)] = Run_fluidsModel(MetTwo_samples(i,:), ...
        i, num_ves, art, ven, ntp);
end

parfor i=1:Ns
    [MetThree_pressure(i,:), MetThree_flow(i,:,:)] = Run_fluidsModel(MetThree_samples(i,:), ...
        i, num_ves, art, ven, ntp);
end

parfor i=1:Ns
    [MetTwo_largeModel_pressure(i,:), MetTwo_largeModel_flow(i,:,:)] = ...
        Run_fluidsModel(MetTwo_largeModel_samples(i,:), i, num_ves, art, ven, ntp);
end

parfor i=1:Ns
    [MetThree_improved_pressure(i,:), MetThree_improved_flow(i,:,:)] = ...
        Run_fluidsModel(MetThree_postComp_samples(i,:), i, num_ves, art, ven, ntp);
end

%% Assess accuracy and UQ in parameter space

cd('/Assessment/Pulmonary')

nd = 4;

% simulator
[bandwidth_simulator_Silverman,bandwidth_simulator_CV] = GetBandwidth(samples_simulator(:,1:nd),1);

% MetOne
% Get bandwidth
[bandwidth_MetOne_Silverman,bandwidth_MetOne_CV] = GetBandwidth(MetOne_samples(:,1:nd),1);

% Get predictive density and Hellinger distance for both types of bandwidth
[MetOne_Density_Silverman_ParEstimate, MetOne_H_par_Silverman] = ...
    GetHellingerDist(samples_simulator(:,1:nd), MetOne_samples(:,1:nd), MetOne_parEstimate, ...
    bandwidth_simulator_Silverman,bandwidth_MetOne_Silverman);

[MetOne_Density_CV_ParEstimate, MetOne_H_par_CV] = ...
    GetHellingerDist(samples_simulator(:,1:nd), MetOne_samples(:,1:nd), MetOne_parEstimate, ...
    bandwidth_simulator_CV,bandwidth_MetOne_CV);

% MetTwo
% Get bandwidth
[bandwidth_MetTwo_Silverman,bandwidth_MetTwo_CV] = GetBandwidth(MetTwo_samples(:,1:nd),1);

% Get predictive density and Hellinger distance for both types of bandwidth
[MetTwo_Density_Silverman_ParEstimate, MetTwo_H_par_Silverman] = ...
    GetHellingerDist(samples_simulator(:,1:nd), MetTwo_samples(:,1:nd), MetTwo_parEstimate, ...
    bandwidth_simulator_Silverman,bandwidth_MetTwo_Silverman);

[MetTwo_Density_CV_ParEstimate, MetTwo_H_par_CV] = ...
    GetHellingerDist(samples_simulator(:,1:nd), MetTwo_samples(:,1:nd), MetTwo_parEstimate, ...
    bandwidth_simulator_CV,bandwidth_MetTwo_CV);

% MetThree
% Get bandwidth
[bandwidth_MetThree_Silverman,bandwidth_MetThree_CV] = GetBandwidth(MetThree_samples(:,1:nd),1);

% Get predictive density and Hellinger distance for both types of bandwidth
[MetThree_Density_Silverman_ParEstimate, MetThree_H_par_Silverman] = ...
    GetHellingerDist(samples_simulator(:,1:nd), MetThree_samples(:,1:nd), MetThree_parEstimate, ...
    bandwidth_simulator_Silverman,bandwidth_MetThree_Silverman);

[MetThree_Density_CV_ParEstimate, MetThree_H_par_CV] = ...
    GetHellingerDist(samples_simulator(:,1:nd), MetThree_samples(:,1:nd), MetThree_parEstimate, ...
    bandwidth_simulator_CV,bandwidth_MetThree_CV);

% want minimum negative log probability
MetOne_negLogDensity_Silverman_ParEstimate = -log(MetOne_Density_Silverman_ParEstimate);
MetTwo_negLogDensity_Silverman_ParEstimate = -log(MetTwo_Density_Silverman_ParEstimate);
MetThree_negLogDensity_Silverman_ParEstimate = -log(MetThree_Density_Silverman_ParEstimate);

% negative log probability (Silverman) -- SMALLER IS BETTER
[MetOne_negLogDensity_Silverman_ParEstimate, MetTwo_negLogDensity_Silverman_ParEstimate, MetThree_negLogDensity_Silverman_ParEstimate]
%[175.23       17.549       6.4531]

MetOne_negLogDensity_CV_ParEstimate = -log(MetOne_Density_CV_ParEstimate);
MetTwo_negLogDensity_CV_ParEstimate = -log(MetTwo_Density_CV_ParEstimate); 
MetThree_negLogDensity_CV_ParEstimate = -log(MetThree_Density_CV_ParEstimate);

% negative log probability (CV) -- SMALLER IS BETTER
[MetOne_negLogDensity_CV_ParEstimate, MetTwo_negLogDensity_CV_ParEstimate, MetThree_negLogDensity_CV_ParEstimate]
%[536.56       30.872       6.2665] % SMALLER IS BETTER

% Hellinger distance (Silverman) -- SMALLER IS BETTER
[MetOne_H_par_Silverman, MetTwo_H_par_Silverman, MetThree_H_par_Silverman]
% [0.7884    0.6321    0.3041]

% Hellinger distance (CV) -- SMALLER IS BETTER
[MetOne_H_par_CV, MetTwo_H_par_CV, MetThree_H_par_CV]
% 0.8619    0.7073    0.3425

% calculate MMD if kernelIdx = 4 and Mahalanobis distance if kernelIdx=5:
kernelIdx = 4; % 5

MetOne_MMD = MMDfunction(samples_simulator(:,1:nd), MetOne_samples(:,1:nd), kernelIdx);
MetTwo_MMD = MMDfunction(samples_simulator(:,1:nd), MetTwo_samples(:,1:nd), kernelIdx);
MetThree_MMD = MMDfunction(samples_simulator(:,1:nd), MetThree_samples(:,1:nd), kernelIdx);

[MetOne_MMD, MetTwo_MMD, MetThree_MMD]
% Linear kernel: [1.780111551284790  0.622671484947205   0.067024588584900]
% Mahalanobis: [7.4991    3.2369    2.0890]

%% Assess accuracy and UQ in function space
% Repeat the above first for two time points (systolic and diastolic points for every signal)
% then in a multivariate sense for 512D

nSignals=3; % 3 vessels

% simulator
signal_simulator(1,:) = pressureEstimate_simulator_meanPost;
signal_simulator(2,:) = flowEstimate_simulator_meanPost(:,1)';
signal_simulator(3,:) = flowEstimate_simulator_meanPost(:,2)';
% MetOne
MetOne_signal(1,:) = MetOne_pressureEstimate;
MetOne_signal(2,:) = MetOne_flowEstimate(:,1);
MetOne_signal(3,:) = MetOne_flowEstimate(:,2);
% MetTwo
MetTwo_signal(1,:) = MetTwo_pressureEstimate;
MetTwo_signal(2,:) = MetTwo_flowEstimate(:,1);
MetTwo_signal(3,:) = MetTwo_flowEstimate(:,2);
% MetThree
MetThree_signal(1,:) = MetThree_pressureEstimate;
MetThree_signal(2,:) = MetThree_flowEstimate(:,1);
MetThree_signal(3,:) = MetThree_flowEstimate(:,2);

% Get distribution of signals in this format (nSignals,ntp,Ns);
signal_simulator_Distr(1,:,:) = pressureSamples_simulator';
signal_simulator_Distr(2,:,:) = (flowSamples_simulator(:,:,1))';
signal_simulator_Distr(3,:,:) = (flowSamples_simulator(:,:,2))';
%
MetOne_signal_Distr(1,:,:) = MetOne_pressure';
MetOne_signal_Distr(2,:,:) = (MetOne_flow(:,:,1))';
MetOne_signal_Distr(3,:,:) = (MetOne_flow(:,:,2))';
%
MetTwo_signal_Distr(1,:,:) = MetTwo_pressure';
MetTwo_signal_Distr(2,:,:) = (MetTwo_flow(:,:,1))';
MetTwo_signal_Distr(3,:,:) = (MetTwo_flow(:,:,2))';
%
MetThree_signal_Distr(1,:,:) = MetThree_pressure';
MetThree_signal_Distr(2,:,:) = (MetThree_flow(:,:,1))';
MetThree_signal_Distr(3,:,:) = (MetThree_flow(:,:,2))';

for i=1:nSignals
    % minimum in second half of the signal is the diastolic (or minimum
    % over the entire time series)
    % maximum is the systolic
    
    %     mi = find(signal_simulator(i,:)==min(signal_simulator(i,ntp/2+1:ntp)));
    mi = find(signal_simulator(i,:)==min(signal_simulator(i,:)));
    ma = find(signal_simulator(i,:)==max(signal_simulator(i,:)));
    Imin(i) = mi(1);
    Imax(i) = ma(1);
    
    MetOne_dias_signalEstimate(i) = MetOne_signal(i,Imin(i));
    MetOne_sys_signalEstimate(i) = MetOne_signal(i,Imax(i));
    
    MetTwo_dias_signalEstimate(i) = MetTwo_signal(i,Imin(i));
    MetTwo_sys_signalEstimate(i) = MetTwo_signal(i,Imax(i));
    
    MetThree_dias_signalEstimate(i) = MetThree_signal(i,Imin(i));
    MetThree_sys_signalEstimate(i) = MetThree_signal(i,Imax(i));
    
    bb1=squeeze(signal_simulator_Distr(i,:,:)); bb1=bb1';
    diasSignal_Distr_simulator(i,:) = bb1(:,Imin(i)); % contains all draws for the ith signal at the time point corresponding to the diastolic point
    sysSignal_Distr_simulator(i,:) = bb1(:,Imax(i)); % contains all draws for the ith signal at the time point corresponding to the systolic point
    %
    % MetOne
    bb1=squeeze(MetOne_signal_Distr(i,:,:)); bb1=bb1';
    MetOne_diasSignal_Distr(i,:) = bb1(:,Imin(i)); % contains all draws for the ith signal at the time point corresponding to the diastolic point
    MetOne_sysSignal_Distr(i,:) = bb1(:,Imax(i)); % contains all draws for the ith signal at the time point corresponding to the systolic point
    %
    % MetTwo
    bb1=squeeze(MetTwo_signal_Distr(i,:,:)); bb1=bb1';
    MetTwo_diasSignal_Distr(i,:) = bb1(:,Imin(i)); % contains all draws for the ith signal at the time point corresponding to the diastolic point
    MetTwo_sysSignal_Distr(i,:) = bb1(:,Imax(i)); % contains all draws for the ith signal at the time point corresponding to the systolic point
    %
    % MetThree
    bb1=squeeze(MetThree_signal_Distr(i,:,:)); bb1=bb1';
    MetThree_diasSignal_Distr(i,:) = bb1(:,Imin(i)); % contains all draws for the ith signal at the time point corresponding to the diastolic point
    MetThree_sysSignal_Distr(i,:) = bb1(:,Imax(i)); % contains all draws for the ith signal at the time point corresponding to the systolic point
    %
    
    % 1D kernel density
    % do this for every signal (univariate sense)
    % simulator
    sysSamples_simulator = sysSignal_Distr_simulator(i,:); % this is functional samples simulator
    diasSamples_simulator = diasSignal_Distr_simulator(i,:); % this is functional samples simulator
    sysSamples_simulator=sysSamples_simulator'; diasSamples_simulator=diasSamples_simulator';
    
    [bandwidth_simulator_sys_Silverman(i),bandwidth_simulator_sys_CV(i)] = GetBandwidth(sysSamples_simulator,1);
    [bandwidth_simulator_dias_Silverman(i),bandwidth_simulator_dias_CV(i)] = GetBandwidth(diasSamples_simulator,1);
    
    % MetOne
    MetOne_sysSamples = MetOne_sysSignal_Distr(i,:); % this is functional samples theirs
    MetOne_diasSamples = MetOne_diasSignal_Distr(i,:); % this is functional samples theirs
    MetOne_sysSamples = MetOne_sysSamples'; MetOne_diasSamples = MetOne_diasSamples';
    
    [bandwidth_MetOne_sys_Silverman(i),bandwidth_MetOne_sys_CV(i)] = ...
        GetBandwidth(MetOne_sysSamples,1);
    [bandwidth_MetOne_dias_Silverman(i),bandwidth_MetOne_dias_CV(i)] = ...
        GetBandwidth(MetOne_diasSamples,1);
    
    % MetTwo
    MetTwo_sysSamples = MetTwo_sysSignal_Distr(i,:); % this is functional samples theirs
    MetTwo_diasSamples = MetTwo_diasSignal_Distr(i,:); % this is functional samples theirs
    MetTwo_sysSamples = MetTwo_sysSamples'; MetTwo_diasSamples = MetTwo_diasSamples';
    
    [bandwidth_MetTwo_sys_Silverman(i),bandwidth_MetTwo_sys_CV(i)] = ...
        GetBandwidth(MetTwo_sysSamples,1);
    [bandwidth_MetTwo_dias_Silverman(i),bandwidth_MetTwo_dias_CV(i)] = ...
        GetBandwidth(MetTwo_diasSamples,1);
    
    % MetThree
    MetThree_sysSamples = MetThree_sysSignal_Distr(i,:); % this is functional samples theirs
    MetThree_diasSamples = MetThree_diasSignal_Distr(i,:); % this is functional samples theirs
    MetThree_sysSamples = MetThree_sysSamples'; MetThree_diasSamples = MetThree_diasSamples';
    
    [bandwidth_MetThree_sys_Silverman(i),bandwidth_MetThree_sys_CV(i)] = ...
        GetBandwidth(MetThree_sysSamples,1);
    [bandwidth_MetThree_dias_Silverman(i),bandwidth_MetThree_dias_CV(i)] = ...
        GetBandwidth(MetThree_diasSamples,1);
    
    %
    %
    % Get predictive density and Hellinger distance for both types of bandwidth
    %
    % MetOne
    %
    [MetOne_Density_Silverman_Signal_dias_Estimate(i), MetOne_H_Signal_dias_Silverman(i)] = ...
        GetHellingerDist(diasSamples_simulator, MetOne_diasSamples, MetOne_dias_signalEstimate(i), ...
        bandwidth_simulator_dias_Silverman(i),bandwidth_MetOne_dias_Silverman(i));
    
    [MetOne_Density_CV_Signal_dias_Estimate(i), MetOne_H_Signal_dias_CV(i)] = ...
        GetHellingerDist(diasSamples_simulator, MetOne_diasSamples, MetOne_dias_signalEstimate(i), ...
        bandwidth_simulator_dias_CV(i),bandwidth_MetOne_dias_CV(i));
    %
    [MetOne_Density_Silverman_Signal_sys_Estimate(i), MetOne_H_Signal_sys_Silverman(i)] = ...
        GetHellingerDist(sysSamples_simulator, MetOne_sysSamples, MetOne_sys_signalEstimate(i), ...
        bandwidth_simulator_sys_Silverman(i),bandwidth_MetOne_sys_Silverman(i));
    
    [MetOne_Density_CV_Signal_sys_Estimate(i), MetOne_H_Signal_sys_CV(i)] = ...
        GetHellingerDist(sysSamples_simulator, MetOne_sysSamples, MetOne_sys_signalEstimate(i), ...
        bandwidth_simulator_sys_CV(i),bandwidth_MetOne_sys_CV(i));
    
    %
    % MetTwo
    %
    [MetTwo_Density_Silverman_Signal_dias_Estimate(i), MetTwo_H_Signal_dias_Silverman(i)] = ...
        GetHellingerDist(diasSamples_simulator, MetTwo_diasSamples, MetTwo_dias_signalEstimate(i), ...
        bandwidth_simulator_dias_Silverman(i),bandwidth_MetTwo_dias_Silverman(i));
    
    [MetTwo_Density_CV_Signal_dias_Estimate(i), MetTwo_H_Signal_dias_CV(i)] = ...
        GetHellingerDist(diasSamples_simulator, MetTwo_diasSamples, MetTwo_dias_signalEstimate(i), ...
        bandwidth_simulator_dias_CV(i),bandwidth_MetTwo_dias_CV(i));
    %
    [MetTwo_Density_Silverman_Signal_sys_Estimate(i), MetTwo_H_Signal_sys_Silverman(i)] = ...
        GetHellingerDist(sysSamples_simulator, MetTwo_sysSamples, MetTwo_sys_signalEstimate(i), ...
        bandwidth_simulator_sys_Silverman(i),bandwidth_MetTwo_sys_Silverman(i));
    
    [MetTwo_Density_CV_Signal_sys_Estimate(i), MetTwo_H_Signal_sys_CV(i)] = ...
        GetHellingerDist(sysSamples_simulator, MetTwo_sysSamples, MetTwo_sys_signalEstimate(i), ...
        bandwidth_simulator_sys_CV(i),bandwidth_MetTwo_sys_CV(i));
    
    %
    % MetThree
    %
    [MetThree_Density_Silverman_Signal_dias_Estimate(i), MetThree_H_Signal_dias_Silverman(i)] = ...
        GetHellingerDist(diasSamples_simulator, MetThree_diasSamples, MetThree_dias_signalEstimate(i), ...
        bandwidth_simulator_dias_Silverman(i),bandwidth_MetThree_dias_Silverman(i));
    
    [MetThree_Density_CV_Signal_dias_Estimate(i), MetThree_H_Signal_dias_CV(i)] = ...
        GetHellingerDist(diasSamples_simulator, MetThree_diasSamples, MetThree_dias_signalEstimate(i), ...
        bandwidth_simulator_dias_CV(i),bandwidth_MetThree_dias_CV(i));
    %
    [MetThree_Density_Silverman_Signal_sys_Estimate(i), MetThree_H_Signal_sys_Silverman(i)] = ...
        GetHellingerDist(sysSamples_simulator, MetThree_sysSamples, MetThree_sys_signalEstimate(i), ...
        bandwidth_simulator_sys_Silverman(i),bandwidth_MetThree_sys_Silverman(i));
    
    [MetThree_Density_CV_Signal_sys_Estimate(i), MetThree_H_Signal_sys_CV(i)] = ...
        GetHellingerDist(sysSamples_simulator, MetThree_sysSamples, MetThree_sys_signalEstimate(i), ...
        bandwidth_simulator_sys_CV(i),bandwidth_MetThree_sys_CV(i));
    
    % next implement MMD
    % univariate sense (for sys and dias separately)
    MetOne_signal_dias_MMD(i) = MMDfunction(diasSamples_simulator, MetOne_diasSamples, kernelIdx);
    MetOne_signal_sys_MMD(i) = MMDfunction(sysSamples_simulator, MetOne_sysSamples, kernelIdx);
    %
    MetTwo_signal_dias_MMD(i) = MMDfunction(diasSamples_simulator, MetTwo_diasSamples, kernelIdx);
    MetTwo_signal_sys_MMD(i) = MMDfunction(sysSamples_simulator, MetTwo_sysSamples, kernelIdx);
    %
    MetThree_signal_dias_MMD(i) = MMDfunction(diasSamples_simulator, MetThree_diasSamples, kernelIdx);
    MetThree_signal_sys_MMD(i) = MMDfunction(sysSamples_simulator, MetThree_sysSamples, kernelIdx);
    
end

% Hellinger distance
[MetOne_H_Signal_sys_Silverman; MetTwo_H_Signal_sys_Silverman; MetThree_H_Signal_sys_Silverman]
[MetOne_H_Signal_dias_Silverman; MetTwo_H_Signal_dias_Silverman; MetThree_H_Signal_dias_Silverman]

[MetOne_H_Signal_sys_CV; MetTwo_H_Signal_sys_CV; MetThree_H_Signal_sys_CV]
[MetOne_H_Signal_dias_CV; MetTwo_H_Signal_dias_CV; MetThree_H_Signal_dias_CV]

% negative log density function space (accuracy)
% MetOne
MetOne_negLogDensity_Silverman_Signal_dias_Estimate = -log(MetOne_Density_Silverman_Signal_dias_Estimate);
MetOne_negLogDensity_CV_Signal_dias_Estimate = -log(MetOne_Density_CV_Signal_dias_Estimate);
MetOne_negLogDensity_Silverman_Signal_sys_Estimate = -log(MetOne_Density_Silverman_Signal_sys_Estimate);
MetOne_negLogDensity_CV_Signal_sys_Estimate = -log(MetOne_Density_CV_Signal_sys_Estimate);

%
% MetTwo
MetTwo_negLogDensity_Silverman_Signal_dias_Estimate = -log(MetTwo_Density_Silverman_Signal_dias_Estimate);
MetTwo_negLogDensity_CV_Signal_dias_Estimate = -log(MetTwo_Density_CV_Signal_dias_Estimate);
MetTwo_negLogDensity_Silverman_Signal_sys_Estimate = -log(MetTwo_Density_Silverman_Signal_sys_Estimate);
MetTwo_negLogDensity_CV_Signal_sys_Estimate = -log(MetTwo_Density_CV_Signal_sys_Estimate);

%
% MetThree
MetThree_negLogDensity_Silverman_Signal_dias_Estimate = -log(MetThree_Density_Silverman_Signal_dias_Estimate);
MetThree_negLogDensity_CV_Signal_dias_Estimate = -log(MetThree_Density_CV_Signal_dias_Estimate);
MetThree_negLogDensity_Silverman_Signal_sys_Estimate = -log(MetThree_Density_Silverman_Signal_sys_Estimate);
MetThree_negLogDensity_CV_Signal_sys_Estimate = -log(MetThree_Density_CV_Signal_sys_Estimate);


% (univariate) MMD for sys and dias points only:
[MetOne_signal_dias_MMD; MetTwo_signal_dias_MMD; MetThree_signal_dias_MMD]
[MetOne_signal_sys_MMD; MetTwo_signal_sys_MMD; MetThree_signal_sys_MMD]

% 1D kernel density plots
figure(31);clf(31)
for i=1:3
    subplot(3,1,i);hold on;
    [f,xi] = ksdensity(MetOne_sysSignal_Distr(i,:));
    plot(xi,f, '-b', 'linewidth', 3);
    set(gca,'fontsize', 30);axis tight
    %
    [f,xi] = ksdensity(MetTwo_sysSignal_Distr(i,:));
    plot(xi,f, '-c', 'linewidth', 3);
    set(gca,'fontsize', 30);axis tight
    
    %
    [f,xi] = ksdensity(MetThree_sysSignal_Distr(i,:));
    plot(xi,f, '--r', 'linewidth', 3);
    yticks([min(f) max(f)])
    ytickformat('%.1g')
    set(gca,'fontsize', 30);axis tight
    
    %
    [f,xi] = ksdensity(sysSignal_Distr_simulator(i,:));
    plot(xi,f, '--k', 'linewidth', 3);
    set(gca,'fontsize', 30);axis tight
    
    
    if i==1
        title('S1 systolic')
    elseif i==2
        title('S2 systolic')
    else
        title('S3 systolic')
    end
    
end
legend('Method I', 'Method II', 'Method III', 'simulator')

%
figure(32);clf(32)
for i=1:3
    subplot(3,1,i);hold on;
    [f,xi] = ksdensity(MetOne_diasSignal_Distr(i,:));
    plot(xi,f, '-b', 'linewidth', 3);
    set(gca,'fontsize', 30);axis tight
    
    %
    [f,xi] = ksdensity(MetTwo_diasSignal_Distr(i,:));
    plot(xi,f, '-c', 'linewidth', 3);
    set(gca,'fontsize', 30);axis tight
    %
    [f,xi] = ksdensity(MetThree_diasSignal_Distr(i,:));
    plot(xi,f, '--r', 'linewidth', 3);
    yticks([min(f) max(f)])
    ytickformat('%.1g')
    set(gca,'fontsize', 30);axis tight
    %
    [f,xi] = ksdensity(diasSignal_Distr_simulator(i,:));
    plot(xi,f, '--k', 'linewidth', 3);
    set(gca,'fontsize', 30);axis tight
    
    if i==1
        title('S1 diastolic')
    elseif i==2
        title('S2 diastolic')
    else
        title('S3 diastolic')
    end
    
end
legend('Method I', 'Method II', 'Method III', 'simulator')

%%% Univariate MMD or Mahalanobis distance for ALL time points now (not
%%% only sys and dias points)
%
kernelIdx = 4; % 4: MMD with linear kernel, 5: Mahalanobis distance

E_MMD = NaN(nSignals,512);
M_MMD = NaN(nSignals,512);
R_MMD = NaN(nSignals,512);

for j=1:512
    
    for i=1:nSignals
        
        s1 = squeeze(signal_simulator_Distr(i,:,:)); s1=s1';
        
        E1 = squeeze(MetOne_signal_Distr(i,:,:)); E1=E1';
        
        M1 = squeeze(MetTwo_signal_Distr(i,:,:)); M1=M1';
        
        R1 = squeeze(MetThree_signal_Distr(i,:,:)); R1=R1';
        
        E_MMD(i,j) = MMDfunction(s1(:,j), E1(:,j), kernelIdx);
        M_MMD(i,j) = MMDfunction(s1(:,j), M1(:,j), kernelIdx);
        R_MMD(i,j) = MMDfunction(s1(:,j), R1(:,j), kernelIdx);
        
    end
end

% mean of all univariate MMDs over all time points
mean(E_MMD,2)
mean(M_MMD,2)
mean(R_MMD,2)

for i=1:nSignals
    figure(i);clf(i)
    plot(E_MMD(i,:),'.b', 'markersize', 20);
    hold on;plot(M_MMD(i,:),'.c', 'markersize', 20);
    hold on;plot(R_MMD(i,:),'.r', 'markersize', 20)
    set(gca, 'fontsize', 15);axis tight
    xlabel('Time point'); ylabel('Univariate MMD')
    if kernelIdx==4
        ylabel('Univariate MMD')
    elseif kernelIdx==5
        ylabel('Univariate Mahalanobis')
    end
    legend('Method I', 'Method II', 'Method III')
    if i==1
        title('S1')
    elseif i==2
        title('S2')
    else
        title('S3')
    end
end

%%% Multivariate (512D) MMD or Mahalanobis distance

kernelIdx = 5; % 4: MMD with linear kernel, 5: Mahalanobis distance

MetOne_signal_allTimeP_MMD = NaN(nSignals,1);
MetTwo_signal_allTimeP_MMD = NaN(nSignals,1);
MetThree_signal_allTimeP_MMD = NaN(nSignals,1);

for i=1:nSignals
    
    s1 = squeeze(signal_simulator_Distr(i,:,:)); s1=s1';
    
    E1 = squeeze(MetOne_signal_Distr(i,:,:)); E1=E1';
    
    M1 = squeeze(MetTwo_signal_Distr(i,:,:)); M1=M1';
    
    R1 = squeeze(MetThree_signal_Distr(i,:,:)); R1=R1';
    
    
    % 512D MMD
    
    MetOne_signal_allTimeP_MMD(i) = MMDfunction(s1, E1, kernelIdx);
    %
    MetTwo_signal_allTimeP_MMD(i) = MMDfunction(s1, M1, kernelIdx);
    %
    MetThree_signal_allTimeP_MMD(i) = MMDfunction(s1, R1, kernelIdx);
    
end

% 512D MMD or Mahalanobis
[MetOne_signal_allTimeP_MMD; MetTwo_signal_allTimeP_MMD; MetThree_signal_allTimeP_MMD]

%% measure the percent deviation (intuitive metric)
Simulator_postMean = mean(samples_simulator(:,1:nd));
MetOne_postMean = mean(MetOne_samples(:,1:nd));
MetTwo_postMean = mean(MetTwo_samples(:,1:nd));
MetThree_postMean = mean(MetThree_samples(:,1:nd));

Simulator_postVar = var(samples_simulator(:,1:nd));
MetOne_postVar = var(MetOne_samples(:,1:nd));
MetTwo_postVar = var(MetTwo_samples(:,1:nd));
MetThree_postVar = var(MetThree_samples(:,1:nd));

percDev_par = @(p1,p2) mean(abs((p1-p2)./p1));

MetOne_percDev_Mean = percDev_par(Simulator_postMean,MetOne_postMean);
MetTwo_percDev_Mean = percDev_par(Simulator_postMean,MetTwo_postMean);
MetThree_percDev_Mean = percDev_par(Simulator_postMean,MetThree_postMean);

MetOne_percDev_Var = percDev_par(Simulator_postVar,MetOne_postVar);
MetTwo_percDev_Var = percDev_par(Simulator_postVar,MetTwo_postVar);
MetThree_percDev_Var = percDev_par(Simulator_postVar,MetThree_postVar);

[MetOne_percDev_Mean,MetTwo_percDev_Mean,MetThree_percDev_Mean]

[MetOne_percDev_Var,MetTwo_percDev_Var,MetThree_percDev_Var]

%% Evaluate inference accuracy in log likelihood space
cd('Assessment/Pulmonary')
  
% add path to GPstuff toolbox
addpath(genpath('Assessment/Pulmonary/GPstuff-4.7'))

%%%% DATA/PREDICTIONS

clearvars -except pressureSamples_simulator flowSamples_simulator MetTwo_pressure ...
    MetTwo_flow MetThree_pressure MetThree_flow MetTwo_largeModel_pressure ...
    MetTwo_largeModel_flow MetThree_improved_pressure MetThree_improved_flow ...
    FlowData PressureData samples_simulator MetTwo_samples_all MetThree_samples ...
    MetTwo_largeModel_samples_all MetThree_postComp_samples

% simulator
Simulator_pulmonary_pressure = pressureSamples_simulator;
Simulator_pulmonary_flow = permute(flowSamples_simulator,[1,3,2]); %(500,2,512)

% MetTwo
MetTwo_pulmonary_pressure = MetTwo_pressure;
MetTwo_pulmonary_flow = permute(MetTwo_flow,[1,3,2]); %(500,2,512)

% MetThree
MetThree_pulmonary_pressure = MetThree_pressure;
MetThree_pulmonary_flow = permute(MetThree_flow,[1,3,2]); %(500,2,512)

% MetTwo large
MetTwo_large_pulmonary_pressure = MetTwo_largeModel_pressure;
MetTwo_large_pulmonary_flow = permute(MetTwo_largeModel_flow,[1,3,2]); %(500,2,512)

% MetThree improved
MetThree_improved_pulmonary_pressure = MetThree_improved_pressure;
MetThree_improved_pulmonary_flow = permute(MetThree_improved_flow,[1,3,2]); %(500,2,512)
    
%%%%% PARAMETER SAMPLES

%%% simulator

Simulator_lgt_samples = samples_simulator(:,end);
Simulator_magns2_samples = samples_simulator(:,end-1);

%%% MetTwo

MetTwo_lgt_samples = exp(MetTwo_samples_all(:,1))*0.85;
MetTwo_magns2_samples = exp(MetTwo_samples_all(:,2));

%%% MetThree

MetThree_lgt_samples = MetThree_samples(:,end-1);
MetThree_magns2_samples = MetThree_samples(:,end);

%%% MetTwo large

MetTwo_large_lgt_samples = exp(MetTwo_largeModel_samples_all(:,1))*0.85;
MetTwo_large_magns2_samples = exp(MetTwo_largeModel_samples_all(:,2));

%%% MetThree improved

MetThree_improved_lgt_samples = MetThree_postComp_samples(:,end-1);
MetThree_improved_magns2_samples = MetThree_postComp_samples(:,end);

%%% takes all 500  samples for lgt and magns2, and corresponding 500 signals
s2 = 1e-06; % jitter value
T = 0.85; % period of one heartbeat
ntp = 512;

Simulator_loglik = ComputeLogLik(Simulator_lgt_samples, Simulator_magns2_samples, Simulator_pulmonary_flow, FlowData, Simulator_pulmonary_pressure, PressureData, s2, T, ntp);

MetTwo_loglik = ComputeLogLik(MetTwo_lgt_samples, MetTwo_magns2_samples, MetTwo_pulmonary_flow, FlowData, MetTwo_pulmonary_pressure, PressureData, s2, T, ntp);

MetThree_loglik = ComputeLogLik(MetThree_lgt_samples, MetThree_magns2_samples, MetThree_pulmonary_flow, FlowData, MetThree_pulmonary_pressure, PressureData, s2, T, ntp);

MetTwo_large_loglik = ComputeLogLik(MetTwo_large_lgt_samples, MetTwo_large_magns2_samples, MetTwo_large_pulmonary_flow, FlowData, MetTwo_large_pulmonary_pressure, PressureData, s2, T, ntp);

MetThree_improved_loglik = ComputeLogLik(MetThree_improved_lgt_samples, MetThree_improved_magns2_samples, MetThree_improved_pulmonary_flow, FlowData, MetThree_improved_pulmonary_pressure, PressureData, s2, T, ntp);

%%% plotting

figure(4);clf(4);boxplot([MetThree_improved_loglik,MetThree_loglik,MetTwo_large_loglik,MetTwo_loglik,Simulator_loglik],...
    'Labels',{'Method III post-comp', 'Method III', 'Method II post-comp', 'Method II', 'Simulator'},'Orientation','horizontal')
title('Log likelihood')
set(gca,'fontsize',40)

figure(202);clf(202)
subplot(1,2,1);hold on;
[f,xi] = ksdensity(MetTwo_lgt_samples);
plot(xi,f, '-c', 'linewidth', 3);hold on
set(gca, 'fontsize', 40); axis tight
% yticks([min(f) max(f)])
% ytickformat('%.1g')

[f,xi] = ksdensity(MetTwo_large_lgt_samples);
plot(xi,f, '--c', 'linewidth', 3);hold on
set(gca, 'fontsize', 40); axis tight
% yticks([min(f) max(f)])
% ytickformat('%.1g')

%
[f,xi] = ksdensity(MetThree_lgt_samples);
plot(xi,f, '-r', 'linewidth', 3);
set(gca, 'fontsize', 40); axis tight
yticks([min(f) max(f)])
ytickformat('%.1g')

[f,xi] = ksdensity(MetThree_improved_lgt_samples);
plot(xi,f, '--r', 'linewidth', 3);
set(gca, 'fontsize', 40); axis tight
% yticks([min(f) max(f)])
% ytickformat('%.1g')

[f,xi] = ksdensity(Simulator_lgt_samples);
plot(xi,f, '--k', 'linewidth', 3);
set(gca, 'fontsize', 40); axis tight
% yticks([min(f) max(f)])
% ytickformat('%.1g')

title('GP lengthscale (noise parameter)')

subplot(1,2,2);hold on;
[f,xi] = ksdensity(MetTwo_magns2_samples);
plot(xi,f, '-c', 'linewidth', 3);hold on
set(gca, 'fontsize', 40); axis tight

[f,xi] = ksdensity(MetTwo_large_magns2_samples);
plot(xi,f, '--c', 'linewidth', 3);hold on
set(gca, 'fontsize', 40); axis tight
yticks([min(f) max(f)])
ytickformat('%.1g')

%
[f,xi] = ksdensity(MetThree_magns2_samples);
plot(xi,f, '-r', 'linewidth', 3);
set(gca, 'fontsize', 40); axis tight

%
[f,xi] = ksdensity(MetThree_improved_magns2_samples);
plot(xi,f, '--r', 'linewidth', 3);
set(gca, 'fontsize', 40); axis tight

[f,xi] = ksdensity(Simulator_magns2_samples);
plot(xi,f, '--k', 'linewidth', 3);
set(gca, 'fontsize', 40); axis tight

title('GP amplitude (noise parameter)')

legend('Method II', 'Method II (post-comp)', 'Method III', 'Method III (post-comp)', 'simulator')
