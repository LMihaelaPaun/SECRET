function OptimHistory = GradientAlgorithm_KDbw(h0, A, samples, sc)

n=size(samples,1);
d = size(samples,2);

% Set up shared variables with OUTFUN
OptimHistory.x = [];
OptimHistory.fval = [];

%% Contrained optimization with gradient based method (sqp algorithm)
options=optimoptions('fmincon', 'Display','iter', 'Algorithm','sqp', ...
    'OutputFcn',@outfun, ...
    'StepTolerance',  1.0000e-6, 'OptimalityTolerance', 1.0000e-6, ...
    'ConstraintTolerance', 1.0000e-6, 'FiniteDifferenceType', 'central');


[x,fval] = fmincon(@(x)GetObjFct(x), ...
    h0, [], [], [], [], zeros(d,1), 10^10*ones(d,1), [], options);

    function stop = outfun(x,optimValues,state)
        
        stop = false;
        
        switch state
            case 'init'
                hold on
            case 'iter'
                % Concatenate current point and objective function value with history
                % x must be a row vector
                OptimHistory.fval = [OptimHistory.fval; optimValues.fval];
                OptimHistory.x = [OptimHistory.x; x];
                                
            case 'done'
                hold off
            otherwise
        end
        
    end

    function ObjFct = GetObjFct(h)
        % Get objective function
        
        % original scale for h before using it
        h = h.*sc;
        
        kernel = @(xj,xi,bw) prod( exp(-((xj-xi).^2)./(2.*(bw.^2))) );
%                 kernel = @(xj,xi,bw) exp(-((xj-xi).^2)./(2.*(bw.^2)));

        temp = zeros(n,1);
        for i=1:n % leave the i^th point out
            for j=1:n-1
                t = A(i,j,:);t=t(:);t=t';
                temp(i) = temp(i) + kernel(t,samples(i,:),h);
            end
        end
        LL = mean(log(temp)) - log((n-1)*prod(h));
        
        ObjFct = - LL; % minimise negative log likelihood
        
    end

end
