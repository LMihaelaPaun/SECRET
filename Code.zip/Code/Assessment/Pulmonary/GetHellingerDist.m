function [myDensity_theirParEstimate, H] = GetHellingerDist(samples_mine, samples_theirs, ...
    estimate_theirs, bandwidth_mine, bandwidth_theirs)

l_mine = min(samples_mine);
u_mine = max(samples_mine);

l_theirs = min(samples_theirs);
u_theirs = max(samples_theirs);

nd = numel(l_mine);

% take density evaluation points (common to both mine and their input support)
l_common = min(l_mine, l_theirs);
u_common = max(u_mine, u_theirs);

np = 20; % try 20, 30, 40, 50 and check effect on hellinger distance
for i=1:nd
    gridx(i,:) = linspace(l_common(i), u_common(i), np);
end

if nd == 4
    
    [x1,x2,x3,x4] = ndgrid(gridx(1,:),gridx(2,:),gridx(3,:),gridx(4,:));
    x1 = x1(:,:)';
    x2 = x2(:,:)';
    x3 = x3(:,:)';
    x4 = x4(:,:)';
    
    pts = [x1(:) x2(:) x3(:) x4(:)];
    
    xx=gridx(1,:);yy=gridx(2,:);zz=gridx(3,:); ww=gridx(4,:);
    xx=xx'; yy=yy'; zz=zz'; ww=ww';
    
    %
    % Construct multivarite kernel densities
    
    myDensity = mvksdensity(samples_mine,pts,'Bandwidth',bandwidth_mine);
    theirDensity = mvksdensity(samples_theirs,pts,'Bandwidth',bandwidth_theirs);
    
    %%% gives prob(their estimate|MCMC samples)
    myDensity_theirParEstimate = mvksdensity(samples_mine,estimate_theirs,'Bandwidth',bandwidth_mine);
    
    % Compute the Hellinger distance between their density and my density
    
    myDensity = reshape(myDensity,np,np,np,np);
    theirDensity = reshape(theirDensity,np,np,np,np);
    
    F_hell = sqrt(myDensity.*theirDensity);
    
    I_hell = trapz(ww,trapz(zz,trapz(yy,trapz(xx,F_hell,4),3),2));
    
else % nd==1
    
    pts = gridx;
    
    myDensity = ksdensity(samples_mine,pts,'Bandwidth',bandwidth_mine);
    theirDensity = ksdensity(samples_theirs,pts,'Bandwidth',bandwidth_theirs);
    
    %%% gives prob(their estimate|MCMC samples)
    myDensity_theirParEstimate = ksdensity(samples_mine,estimate_theirs,...
        'Bandwidth',bandwidth_mine);
    
    I_hell = trapz(pts,sqrt(myDensity.*theirDensity)); % for 1D case
    
end

% Hellinger distance
H = 1-I_hell;

end

