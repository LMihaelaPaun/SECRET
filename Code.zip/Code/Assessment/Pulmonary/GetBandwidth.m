function [bandwidth_Silverman, bandwidth_MLCV] = GetBandwidth(samples, do_CV)

nS = size(samples,1);

nd = size(samples,2);

stdVec = std(samples); % standard deviation of every parameter

% compute bandwidth for every parameter using silverman's rule
bandwidthSilverman = @(stdV, nd, nS) stdV .* (4/((nd+2)*nS))^(1/(nd+4));

bandwidth_Silverman = bandwidthSilverman(stdVec, nd, nS);

if do_CV == 1
    
    %% Cross-validation
    
    A(1,:,:) = samples(2:end,:);
    A(nS,:,:) = samples(1:end-1,:);
    for i=2:(nS-1)
        A(i,:,:) = samples([1:(i-1), (i+1):end],:);
    end
    
    % different initial values
    
    X = sobolset(nd, 'Skip',2e12,'Leap',0.95e15);
    
    n = size(X,1);
    
    x = NaN(n,nd);
    
    s_bw = std(samples(:,1:nd));
    l_bw = s_bw-0.5*s_bw;
    u_bw = s_bw+0.5*s_bw;
    
    for i=1:nd
        x(:,i) = l_bw(i) + (u_bw(i)-l_bw(i)) * X(1:n,i);
    end
    
    sc_bw = max(abs(l_bw),abs(u_bw));
    
    parfor i=1:n
        history(i) = GradientAlgorithm_KDbw(x(i,:)./sc_bw, A, samples, sc_bw);
    end
    
    FinalxValues=[];FinalfValues=[];
    for i=1:n
        FinalxValues(i,:) = history(i).x(end,:).*sc_bw;
        FinalfValues(i) = history(i).fval(end,:);
    end
    
    bandwidth_MLCV = FinalxValues(FinalfValues==min(FinalfValues),:);
    bandwidth_MLCV = bandwidth_MLCV(1,:);
    
else
    
    bandwidth_MLCV = NaN;
    
end

end

