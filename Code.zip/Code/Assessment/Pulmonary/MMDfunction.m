function MMD = MMDfunction(samples_mine, samples_theirs, kernelIdx)

nd = size(samples_mine,2);

nS = size(samples_mine,1);

%kernelIdx -- 1: RBF, 2: Matern 3/2, 3: Ornstein-Uhlenbeck, 4: linear
%5: Mahalanobis distance

if (kernelIdx == 4 || kernelIdx == 5) && nd > 1
    
    AllSamples = [samples_mine; samples_theirs];
    
    meanAllSamples = NaN(nS*2,1);
    varAllSamples = NaN(nS*2,1);
    
    for i=1:nS*2
        meanAllSamples(i) = mean(AllSamples(i,:));
        
        varAllSamples(i) = var(AllSamples(i,:));
    end
    
    stdSamples = sqrt(mean(varAllSamples));
    meanSamples = mean(meanAllSamples);
    
    
    samples_mine = (samples_mine-meanSamples)./stdSamples;
    samples_theirs = (samples_theirs-meanSamples)./stdSamples;
    
end


rFct = @(x,y,a) sum( ((x-y).^2)./(a.^2) , 2); % vector wise

if kernelIdx == 1
    
    kernelFct = @(x,y,a) exp(- 0.5 * rFct(x,y,a) );
    
elseif kernelIdx == 2
    
    kernelFct = @(x,y,a) (1 + sqrt(3) * sqrt( rFct(x,y,a) ) ) .* ...
        exp( -sqrt(3) * sqrt( rFct(x,y,a) ) );
    
elseif kernelIdx == 3
    
    kernelFct = @(x,y,a) exp(- sqrt( rFct(x,y,a) ) );
    
end

AA = 1:nS;
Out = nchoosek(AA, 2);
mOut = size(Out,1);

if kernelIdx==4 || kernelIdx == 5
    
    covchain = []; meanchain = []; wsum = [];
    covchain = covupd(samples_mine,1, covchain,meanchain,wsum);
    SigmaVarMat = eye(nd,nd)/(covchain+(1e-09)*eye(nd,nd));%inv(covchain); % assuming var_vec is size (nd,1)

else
    
    distF = @(xx,yy) sqrt((xx - yy) .^ 2);
    
    dist = NaN(mOut,nd);
    
    for i=1:mOut
        
        dist(i,:) = distF(samples_mine(Out(i,1),:),samples_mine(Out(i,2),:));
        
    end

    
    % a is the median distance between all pairs of points in my samples
    a = median(dist);
    
   
end

% (x,y)
T = [repelem(samples_mine,nS,1) repmat(samples_theirs,nS,1)];
A = T(:,1:nd);
B = T(:,nd+1:end);

if kernelIdx == 4
    
    kxy=mean(sum((A*SigmaVarMat).*B,2));
    
elseif kernelIdx == 1 || kernelIdx == 2 || kernelIdx == 3
    
    kxy = mean(kernelFct(A,B,a));
    
elseif kernelIdx == 5
    
    MH = mean(sum(((A-B)*SigmaVarMat).*(A-B),2));
    
end

if kernelIdx == 1 || kernelIdx == 2 || kernelIdx == 3 || kernelIdx == 4
    
    % (x,x)
    T = [repelem(samples_mine,nS,1) repmat(samples_mine,nS,1)];
    A = T(:,1:nd);
    B = T(:,nd+1:end);
    
    %%%
    if kernelIdx==4
        
        kf=sum((A*SigmaVarMat).*B,2); % does this equal the following? up to decimals

    elseif kernelIdx == 1 || kernelIdx == 2 || kernelIdx == 3
        
        kf = kernelFct(A,B,a);
        
    end
    
    
    % eliminate identical entries (xi,xi), as we need (xi,xj)
    rmIdx = nS*((1:nS)-1)+(1:nS);
    kf(rmIdx,:) = [];
    kxx = mean(kf);
    
    % (y,y)
    T = [repelem(samples_theirs,nS,1) repmat(samples_theirs,nS,1)];
    A = T(:,1:nd);
    B = T(:,nd+1:end);
    
    if kernelIdx == 4
        
        kf=sum((A*SigmaVarMat).*B,2);
        
    elseif kernelIdx == 1 || kernelIdx == 2 || kernelIdx == 3
        
        kf = kernelFct(A,B,a);
        
    end
    
    % eliminate identical entries (yi,yi), as we need (yi,yj)
    rmIdx = nS*((1:nS)-1)+(1:nS);
    kf(rmIdx,:) = [];
    kyy = mean(kf);
    
end

%
if kernelIdx == 1 || kernelIdx == 2 || kernelIdx == 3 || kernelIdx == 4
    MMD = kxx - 2*kxy + kyy;
elseif kernelIdx == 5
    MMD = MH;
    
end
end
