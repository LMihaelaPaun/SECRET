function loglik = ComputeLogLik(lgt_vec, magns2_vec, flow, trueFlow, pressure, truePressure, s2, T, ntp)

% flow/pressure is prediction
% trueFlow/truePressure is competition data

deltaT = T/(ntp-1);
t = 0:deltaT:T;

t = t';

loglik = zeros(numel(lgt_vec),1);

for i=1:numel(lgt_vec)
    
    %
    lik = lik_gaussian('sigma2', s2, 'sigma2_prior', prior_fixed);
    
    gpcf = gpcf_matern32('lengthScale', lgt_vec(i), ...
        'magnSigma2', magns2_vec(i),...
        'lengthScale_prior', prior_fixed, 'magnSigma2_prior', prior_fixed);
    
    gp = gp_set('lik', lik, 'cf', gpcf, 'jitterSigma2', 0);
    
    [~,C] = gp_trcov(gp, t);
    
    [L,posdef] = chol(C,'lower');
    

    if posdef == 0
         
        LogDet = ntp * log(2*pi) + 2*sum(log(diag(L)));

        for j = 1:2 % loop over no of vessels
            
            a = L\(squeeze(flow(i,j,:)) - (trueFlow(:,j)));
            
            MH = a'*a; % Mahalanobis distance
                       
            loglik(i) = loglik(i) + (-0.5*LogDet - 0.5*MH); % sum of likelihoods for every vessel
        end
        
        % now for pressure
        
        a = L\((pressure(i,:))' - truePressure);
        
        MH = a'*a; % Mahalanobis distance
        
        loglik(i) = loglik(i) + (-0.5*LogDet - 0.5*MH); % sum of likelihoods for every vessel
        
    else
        
        loglik(i) = -10^10; % likelihood zero
        
    end

end

end

