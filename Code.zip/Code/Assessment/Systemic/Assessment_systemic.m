%%%% Systemic model: assessment

clear; close all

% path to participants' entries
addpath(genpath('CompetitionEntries'))

% path to competition data
addpath(genpath('CompetitionData'))

% path to systemic simulator
addpath(genpath('SystemicModel/Code'))

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Load parameter estimates

% data generating parameter values
truePar=[-32.9,426000,-40.6,643000,0.88];

% parameter estimates from all methods
MetOne_parEstimate = csvread('/CompetitionEntries/Systemic/MetOne_estimate_systemic.csv', 1, 0);
%
MetTwo_parEstimate = importdata('/CompetitionEntries/Systemic/MetTwo_estimate_systemic.txt');
%
MetThree_parEstimate = importdata('/CompetitionEntries/Systemic/MetThree_estimate_systemic.txt');
MetThree_parEstimate = MetThree_parEstimate';
%
MetThree_postComp_parEstimate = importdata('/CompetitionEntries/Systemic/MetThree_PostCompSystemicParameters.txt'); 
MetThree_postComp_parEstimate = MetThree_postComp_parEstimate';

%% Call fluids model (simulator) for these estimates
% but only AFTER EDITING THE MAKEFILE (instructions in
% /SystemicModel/Makefile_Instructions)
cd('/SystemicModel/Code')
!make clean
!make

% no of time points in the time series
ntp = 512;

% no of vessels we use data for inference from
nv = 9;

file_id = 1;

[MetOne_pressureEstimate, MetOne_flowEstimate] = Run_fluidsModel(MetOne_parEstimate, ...
    file_id, nv, ntp);

[MetTwo_pressureEstimate, MetTwo_flowEstimate] = Run_fluidsModel(MetTwo_parEstimate, ...
    file_id, nv, ntp);

[MetThree_pressureEstimate, MetThree_flowEstimate] = Run_fluidsModel(MetThree_parEstimate, ...
    file_id, nv, ntp);

%% load competition data
load('/CompetitionData/SystemicData/SystemicModel_CompetitionData.mat')

signalFlow_simulator = FlowData; signalPressure_simulator = PressureData;
MetOne_pressureEstimate_MinMax = [min(MetOne_pressureEstimate), max(MetOne_pressureEstimate)];
MetTwo_pressureEstimate_MinMax = [min(MetTwo_pressureEstimate), max(MetTwo_pressureEstimate)];
MetThree_pressureEstimate_MinMax = [min(MetThree_pressureEstimate), max(MetThree_pressureEstimate)];

%% Assessment
cd('/Assessment/Systemic')

% assessment formula in parameter space
WRMSE_par = @(p1,p2) sqrt(sum(((p1-p2)./p1).^2));

% assessment formula in function (output) space
WRMSE_function = @(y1,y2) sqrt(sum(((y1-y2)./max(y1)).^2));

MetOne_WRMSE_paramSpace = WRMSE_par(truePar,MetOne_parEstimate);
MetTwo_WRMSE_paramSpace = WRMSE_par(truePar,MetTwo_parEstimate);
MetThree_WRMSE_paramSpace = WRMSE_par(truePar,MetThree_parEstimate);

MetThree_postComp_WRMSE_paramSpace = WRMSE_par(truePar,MetThree_postComp_parEstimate); % post-competition for method three

[MetOne_WRMSE_paramSpace, MetTwo_WRMSE_paramSpace, MetThree_WRMSE_paramSpace]
% [0.091085     9.4534e-07     0.019556]

nSignals = size(signalFlow_simulator, 2) + 1;% no of signals

MetOne_accuracy_function = NaN(nSignals,1);
MetTwo_accuracy_function = NaN(nSignals,1);
MetThree_accuracy_function = NaN(nSignals,1);

for i=1:nSignals-1
    MetOne_accuracy_function(i) = WRMSE_function(signalFlow_simulator(:,i),MetOne_flowEstimate(:,i));
    %
    MetTwo_accuracy_function(i) = WRMSE_function(signalFlow_simulator(:,i),MetTwo_flowEstimate(:,i));
    %
    MetThree_accuracy_function(i) = WRMSE_function(signalFlow_simulator(:,i),MetThree_flowEstimate(:,i));

end

MetOne_accuracy_function(end) = WRMSE_function(signalPressure_simulator,MetOne_pressureEstimate_MinMax);
MetTwo_accuracy_function(end) = WRMSE_function(signalPressure_simulator,MetTwo_pressureEstimate_MinMax);
MetThree_accuracy_function(end) = WRMSE_function(signalPressure_simulator,MetThree_pressureEstimate_MinMax);

[MetOne_accuracy_function, MetTwo_accuracy_function, MetThree_accuracy_function]

% measure the percent deviation (intuitive metric)
percError_par = @(p1,p2) mean(abs(((p1-p2)./p1)));

MetOne_percError = percError_par(truePar,MetOne_parEstimate);
MetTwo_percError = percError_par(truePar,MetTwo_parEstimate);
MetThree_percError = percError_par(truePar,MetThree_parEstimate);

[MetOne_percError, MetTwo_percError, MetThree_percError]