﻿This folder contains all the code and data for the paper “SECRET: Statistical Emulation for Computational Reverse Engineering and Translation with applications in healthcare”.

It contains several sub-folders:
- SystemicModel: contains the simulator code to obtain predictions from the systemic model (together with Makefile instructions on how to compile the simulator C++ code).
- PulmonaryModel: contains the simulator code to obtain predictions from the pulmonary model (together with Makefile instructions on how to compile the simulator C++ code).
- CompetitionData: contains the competition data, which are data generated from the simulators with pre-set parameter values, and on which participants had to apply their methods.
- MethodsCodes: contains 3 sub-folders, each containing code for the three winning methods.
- CompetitionEntries: contains the results submitted by the three winning participants for both systemic and pulmonary models.
- Assessment: contains the assessment criteria for both systemic and pulmonary models.
 
