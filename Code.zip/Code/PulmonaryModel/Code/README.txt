This directory contains a combination of C++, FORTRAN and MATLAB files that simulate blood pressure and flow in the pulmonary blood circulation using the two-sided structure tree model as a boundary condition. 

COMPILING:
Instructions on how to compile the C++ / FORTRAN code can be found in the file Makefile_Instructions.pdf 
accompanied by the video Makefile_Instructions.mp4.

Data Files: 

Qin.dat: Inflow data used as a left boundary condition for the PDE model.
LA_pressure.dat: Outlet pressure data used as a right boundary condition for the PDE model.

Code Files:

Makefile:     	 Compiles C++/FORTRAN files together
sor06:	  	 The executable file. (sor06.exe on Windows machines)
sor06.h:      	 Header file that initiates the basic, global parameter values.
sor06.c:           A main solver for artery initialization and PDE solution.
arteries.h:        Header file which declares the class "Tube" and all of its
                   objects and functions.
arteries.c:        Main computational code that computes all variables
			 associated with every vessel in the system. Includes calls
			 to new_match.f90 and tools.c.
tools.h:           Header file that initiates the solver tools.
tools.c:           Contains solvers for the nonlinear systems, including 
			 Newton-Raphson method.
Impedance sub.f90: Initializes the admittance matrix and associated variables
new_match.f90: 	 Solves the two-sided structured tree model and provides
			 admittance boundary conditions that are coupled to the
		       large vessel tree.
f90_tools.f90: 	 Root finding, FFT, and iFFT functions to be used in the
			 new_match.f90 file.
run_1D.m:	       MATLAB file that calls the C++ code via the "unix"
			 command. Passes parameter values from MATLAB into sor06.C.
gnuplot.m:         MATLAB file that reads the output files and converts them
			 to the appropriate format for plotting.


Output Files:
output_ID.2d:    The pressure, flow and area for file with index ID.


License:
This project is licensed under the MIT License -  see the LICENSE.txt file for details.
