% This is a driver file that will run the pulmonary fluids model from c++ and
% fortran by passing parameter values needed by the model. This code is a
% working file and comes with NO GUARANTEES.
%
% Authors: MJ Colebank, M Bartolo, MU Qureshi, MS Olufsen
%
% Last edited: 1/27/2020, MJC
%%
clear; clc; close all;
%% Ensure the make file is compiled
!make clean
!make
% make the file executable
! chmod +x sor06

%% FOR PARTICIPANTS TO EDIT
% Consider some random values for the parameters of interest
% within the appropriate range
% Large arterial and venous stiffness are fixed, so we only consider the
% microvascular stiffness
kMV = 1.1e+05; % g/cm^2/s

% Structured tree parameters
alpha = 0.85; % Dimensionless
lrrA = 30;    % Dimensionless, arteriole length-to-radius ratio
lrrV = 40;    % Dimensionless, arteriole length-to-radius ratio

% File ID (useful for running the C++/Fortran code in parallel)
ID = 1;

%% Put the parameters into a vector and run the model
par_nom = [kMV,alpha,lrrA,lrrV,ID];
param_str = mat2str(par_nom);

% Run the model
% NOTE: Windows users need 'sor06.exe', Mac/Linux users need ./sor06

out = unix(sprintf('./sor06 %s',param_str(2:end-1)));

if out == 1
    disp 'there is a model output'
else
    disp 'there is no model output'
end

%% Load all the model results
% NOTE: Results are stored such that the first 1:N entries are the PROXIMAL
% large artery (1-15) and large vein (16-27) predictions, N+1:2N are the
% MIDPOINT predictions in the same vessels, and 2N+1:3N are the DISTAL
% predictions.
% Vessel 1 - Main Pulmonary artery (MPA), Vessel 2/3 - Left/Right pulmonary artery
% Vessel 16:19 - Left inferior, left superior, right inferior, and right
% superior pulmonary veins (connected to left atrium)
% Vessels 8:15 - terminal arteries
% Vessels 20:27 - terminal veins

name = sprintf('output_%d.2d',ID);

data = load(name);

%% Extract data of interest

num_ves = 27;   % Number of large vessels in the tree
art     = 1:15; % Arteries
ven     = 16:27;% Veins

% p - pressure
% q - flow
[~,~,p,q,~,~] = gnuplot(data); % extract data

ntp = size(p,1); % no of time points in the flow or pressure time series

% competition data consists of pressure in vessel 1 (whole time series),
% and flow in vessels 17 and 19 (whole time series),
% so these are the model predictions we save
flow_inference = NaN(ntp,2);

pressure_inference = p(:,art(1)+num_ves); % middle point (x=L/2) pressure prediction in vessel 1 (arteries)

flow_inference(:,1) = -q(:,ven(2)+num_ves); % middle point (x=L/2) flow prediction in vessel 17 (veins)
flow_inference(:,2) = -q(:,ven(4)+num_ves); % middle point (x=L/2) flow prediction in vessel 19 (veins)

%% Do some plotting
% Time vector
t = linspace(0,0.85,ntp);

% Plot midpoint  in the arteries and veins
figure(1);clf(1);
subplot(1,2,1);
plot(t,p(:,art+num_ves),'LineWidth',3);
ylabel('Pressure (mmHg)');
xlabel('Time (s)');
grid on; set(gca,'FontSize',20);

subplot(1,2,2);
plot(t,p(:,ven+num_ves),'LineWidth',3);
xlabel('Time (s)');
grid on; set(gca,'FontSize',20);

figure(2);clf(2)
subplot(1,2,1);
plot(t,q(:,art+num_ves),'LineWidth',3);
ylabel('Flow (mL/s)')
xlabel('Time (s)');
grid on; set(gca,'FontSize',20);

subplot(1,2,2);
plot(t,-q(:,ven+num_ves),'LineWidth',3);
xlabel('Time (s)');
grid on; set(gca,'FontSize',20);