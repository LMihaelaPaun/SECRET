function [pressure, flow] = ExtractData(num_ves, art, ven, file_id)

% NOTE: Results are stored such that the first 1:N entries are the PROXIMAL
% large artery (1-15) and large vein (16-27) predictions, N+1:2N are the
% MIDPOINT predictions in the same vessels, and 2N+1:3N are the DISTAL
% predictions.
% Vessel 1 - Main Pulmonary artery, Vessel 2/3 - Left/Right pulmonary artery
% Vessel 16:19 - Left inferior, left superior, right inferior, and right
% superior pulmonary veins (connected to left atrium)
% Vessels 8:15 - terminal arteries
% Vessels 20:27 - terminal veins

% num_ves = 27;   % Number of large vessels in the tree
% art     = 1:15; % Arteries
% ven     = 16:27;% Veins

data = load(sprintf('output_%d.2d', file_id)); 

[~,~,p,q,~,~] = gnuplot(data);

ntp = size(p,1); % no of time points in the flow/pressure time series

% extract pressure in vessel 1 (so MPA pressure) and flow in vessels 17 and 19 (veins)

%pressure = NaN(ntp,1);
flow = NaN(ntp,2);

pressure = p(:,art(1)+num_ves); % middle point (x=L/2) pressure prediction in MPA (arteries)
%
flow(:,1) = -q(:,ven(2)+num_ves); % middle point (x=L/2) flow prediction in vessel 17 (veins)
flow(:,2) = -q(:,ven(4)+num_ves); % middle point (x=L/2) flow prediction in vessel 19 (veins)

end